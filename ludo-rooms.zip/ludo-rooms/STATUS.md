# STATUS — what is actually verified

Environment used to produce this: Linux sandbox with Node 22 and Python, **no Android SDK, no Gradle, no network**.

## Verified (executed, passing)
| Item | Evidence |
|---|---|
| Backend: 26 automated tests, 0 failures | `cd backend && npm test` |
| Ludo rules: capture, safe squares, exact finish, 6 to leave base, 3-sixes, leave mid-game, 200 random 4-player games always terminate with valid positions | `test/engine.test.js` |
| Auth: register/login/refresh rotation/logout, validation, case-insensitive usernames, login throttle | `test/api.test.js` |
| Friends: search, request/accept/remove, relation states, friend's room visible only if authorized (private rooms hidden from non-friends of the owner) | `test/api.test.js` |
| Rooms: create/discover/search/join/full/leave/owner transfer/idle reaper, private rooms | `test/api.test.js` |
| Chat: room + DM history/paging, friends-only DMs, rate limiting, non-members rejected | `test/api.test.js`, `test/realtime.test.js` |
| Realtime: WebSocket auth, presence, broadcasts, voice-state sharing, **full 2-player game played to the end over WebSockets** with turn enforcement and a mid-game disconnect/reconnect that restores identical state | `test/realtime.test.js` |
| Persistence: game state survives a server restart | `test/realtime.test.js` |
| Server runs as a real process and answers HTTP | manual `npm start` + curl |
| Board geometry used by the Android canvas: 52 unique squares, start squares/lane entries consistent with the engine | scripted check |
| English and Arabic string files contain every string the Kotlin code references | scripted check |
| Kotlin brackets balanced, XML well-formed | scripted check |

## NOT verified — be aware
1. **The Android app has never been compiled or run.** No Android SDK/Gradle/network was available, so there is
   **no APK** in this archive. ~1,900 lines of Kotlin were written carefully but unverified; expect a few compile
   errors (typically imports or Compose/Agora API signatures) on first build. Send me the Gradle output and they
   get fixed. Exact steps: README.md §2.
2. **No Android UI flow has been tested** (login screen, lists, board rendering/taps, chat UI, language switch).
   The *backend behaviour behind each flow* is tested; the screens are not.
3. **Voice**: the Agora integration (client wrapper in `voice/VoiceEngine.kt`, token builder in `backend/src/agora.js`)
   is untested against Agora. The token builder follows Agora's documented AccessToken2 layout and has structural unit tests only;
   it needs a real Agora project to validate. Dependency `io.agora.rtc:voice-sdk:4.3.1` was not resolved.
4. Microphone/audio behaviour, background voice (no foreground service yet), push notifications: not implemented/tested.

## CI
`.github/workflows/build.yml` (backend tests + debug APK build, uploads the APK as an artifact) is written but has not run yet; its YAML parses correctly.

## Not implemented (honest scope list)
* Yalla integration — none (no authorized access). The app is fully independent.
* Turn timers / auto-play for AFK players; spectators; password reset / e-mail; account deletion; reporting/blocking.
* Unread counters and a DM conversation list (DMs open from the friends list).
* Automated Android tests (only `junit` is declared).

## Original XAPK
`Yalla_Ludo_1_5_0_0__1_.apk_` was only read; it is not included here and was never modified
(sha256 `9a671fe058000e1cc949076c70e550d1f064322ad04dd8eaafb80a8586b5b87e`, re-verified at the end).
