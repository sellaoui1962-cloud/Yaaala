import { test } from 'node:test';
import assert from 'node:assert/strict';
import zlib from 'node:zlib';
import { start } from './helpers.js';
import { buildRtcToken } from '../src/agora.js';

test('register, login, refresh rotation, logout', async () => {
  const t = await start();
  try {
    const bad = await t.api('POST', '/api/auth/register', { body: { username: 'a!', password: 'password123' } });
    assert.equal(bad.status, 400);
    const short = await t.api('POST', '/api/auth/register', { body: { username: 'alice', password: 'short' } });
    assert.equal(short.status, 400);
    const reg = await t.api('POST', '/api/auth/register', { body: { username: 'alice', password: 'password123' } });
    assert.equal(reg.status, 201);
    assert.equal((await t.api('POST', '/api/auth/register', { body: { username: 'ALICE', password: 'password123' } })).status, 409, 'case-insensitive unique');
    assert.equal((await t.api('GET', '/api/me')).status, 401);
    assert.equal((await t.api('GET', '/api/me', { token: reg.body.accessToken })).body.user.username, 'alice');

    assert.equal((await t.api('POST', '/api/auth/login', { body: { username: 'alice', password: 'wrongpass1' } })).status, 401);
    const login = await t.api('POST', '/api/auth/login', { body: { username: 'alice', password: 'password123' } });
    assert.equal(login.status, 200);

    const rf = await t.api('POST', '/api/auth/refresh', { body: { refreshToken: login.body.refreshToken } });
    assert.equal(rf.status, 200);
    assert.equal((await t.api('POST', '/api/auth/refresh', { body: { refreshToken: login.body.refreshToken } })).status, 401, 'old refresh token is rotated out');
    await t.api('POST', '/api/auth/logout', { body: { refreshToken: rf.body.refreshToken } });
    assert.equal((await t.api('POST', '/api/auth/refresh', { body: { refreshToken: rf.body.refreshToken } })).status, 401);
  } finally { await t.close(); }
});

test('login is throttled after repeated failures', async () => {
  const t = await start();
  try {
    await t.signup('bob');
    let last;
    for (let i = 0; i < 6; i++) last = await t.api('POST', '/api/auth/login', { body: { username: 'bob', password: 'nope-nope' } });
    assert.equal(last.status, 429);
  } finally { await t.close(); }
});

test('friends: search, request, accept, remove, relations', async () => {
  const t = await start();
  try {
    const a = await t.signup('anna'), b = await t.signup('annabel'), c = await t.signup('carl');
    const s = await t.api('GET', '/api/users/search?q=ann', { token: a.token });
    assert.deepEqual(s.body.users.map(u => u.username), ['annabel']);
    assert.equal(s.body.users[0].relation, 'none');

    assert.equal((await t.api('POST', '/api/friends/request', { token: a.token, body: { username: 'annabel' } })).status, 201);
    assert.equal((await t.api('POST', '/api/friends/request', { token: a.token, body: { username: 'annabel' } })).status, 409);
    assert.equal((await t.api('POST', '/api/friends/request', { token: a.token, body: { username: 'anna' } })).status, 400);
    const bl = await t.api('GET', '/api/friends', { token: b.token });
    assert.equal(bl.body.incoming.length, 1);
    assert.equal((await t.api('GET', '/api/users/search?q=anna', { token: b.token })).body.users.find(u => u.username === 'anna').relation, 'pending_in');

    assert.equal((await t.api('POST', '/api/friends/accept', { token: c.token, body: { userId: a.id } })).status, 404, 'only the addressee can accept');
    assert.equal((await t.api('POST', '/api/friends/accept', { token: b.token, body: { userId: a.id } })).status, 200);
    const al = await t.api('GET', '/api/friends', { token: a.token });
    assert.equal(al.body.friends.length, 1);
    assert.equal(al.body.friends[0].online, false);

    await t.api('DELETE', `/api/friends/${b.id}`, { token: a.token });
    assert.equal((await t.api('GET', '/api/friends', { token: a.token })).body.friends.length, 0);
  } finally { await t.close(); }
});

test('rooms: create, discover, search, join rules, full, leave, ownership transfer', async () => {
  const t = await start();
  try {
    const [a, b, c] = [await t.signup('user_ra'), await t.signup('user_rb'), await t.signup('user_rc')];
    assert.equal((await t.api('POST', '/api/rooms', { token: a.token, body: { name: '', maxPlayers: 4 } })).status, 400);
    assert.equal((await t.api('POST', '/api/rooms', { token: a.token, body: { name: 'x', maxPlayers: 9 } })).status, 400);
    const r1 = (await t.api('POST', '/api/rooms', { token: a.token, body: { name: 'Friday Ludo', maxPlayers: 2 } })).body.room;
    assert.equal(r1.memberCount, 1);
    assert.equal(r1.members[0].displayName, 'USER_RA');

    const list = await t.api('GET', '/api/rooms', { token: b.token });
    assert.equal(list.body.rooms.length, 1);
    assert.equal((await t.api('GET', '/api/rooms?q=zzz', { token: b.token })).body.rooms.length, 0);
    assert.equal((await t.api('GET', '/api/rooms?q=friday', { token: b.token })).body.rooms.length, 1);

    assert.equal((await t.api('POST', `/api/rooms/${r1.id}/join`, { token: b.token })).status, 200);
    assert.equal((await t.api('POST', `/api/rooms/${r1.id}/join`, { token: c.token })).body.error, 'room_full');
    assert.equal((await t.api('POST', `/api/rooms/999/join`, { token: c.token })).status, 404);

    await t.api('POST', '/api/rooms/leave', { token: a.token }); // owner leaves
    const after = (await t.api('GET', `/api/rooms/${r1.id}`, { token: b.token })).body.room;
    assert.equal(after.ownerId, b.id);
    assert.equal(after.memberCount, 1);
    await t.api('POST', '/api/rooms/leave', { token: b.token });
    assert.equal((await t.api('GET', '/api/rooms', { token: c.token })).body.rooms.length, 0, 'empty room closes');
  } finally { await t.close(); }
});

test('private rooms are hidden from search and only joinable by the owner\'s friends', async () => {
  const t = await start();
  try {
    const [o, f, s] = [await t.signup('owner'), await t.signup('friend'), await t.signup('stranger')];
    await t.befriend(o, f);
    const room = (await t.api('POST', '/api/rooms', { token: o.token, body: { name: 'Secret', isPrivate: true } })).body.room;
    assert.equal((await t.api('GET', '/api/rooms', { token: f.token })).body.rooms.length, 0, 'not in public discovery');
    assert.equal((await t.api('POST', `/api/rooms/${room.id}/join`, { token: s.token })).status, 403);
    assert.equal((await t.api('GET', `/api/rooms/${room.id}`, { token: s.token })).status, 403);

    const fl = (await t.api('GET', '/api/friends', { token: f.token })).body.friends[0];
    assert.equal(fl.roomId, room.id, 'friend sees the room the owner is in');
    assert.equal(fl.canJoin, true);
    const sl = await t.befriend(s, f); // stranger befriends the friend, but not the owner
    assert.equal(sl.status, 200);
    const seen = (await t.api('GET', '/api/friends', { token: s.token })).body.friends[0];
    assert.equal(seen.roomId, null, 'private room stays hidden from non-authorized users');

    assert.equal((await t.api('POST', `/api/rooms/${room.id}/join`, { token: f.token })).status, 200);
  } finally { await t.close(); }
});

test('room and direct message history, friends-only DMs, validation', async () => {
  const t = await start();
  try {
    const [a, b, c] = [await t.signup('user_ma'), await t.signup('user_mb'), await t.signup('user_mc')];
    await t.befriend(a, b);
    assert.equal((await t.api('POST', `/api/dm/${c.id}`, { token: a.token, body: { text: 'hi' } })).status, 403);
    assert.equal((await t.api('POST', `/api/dm/${b.id}`, { token: a.token, body: { text: '   ' } })).status, 400);
    for (const text of ['one', 'two', 'three']) await t.api('POST', `/api/dm/${b.id}`, { token: a.token, body: { text } });
    await t.api('POST', `/api/dm/${a.id}`, { token: b.token, body: { text: 'reply' } });
    const h = (await t.api('GET', `/api/dm/${b.id}`, { token: a.token })).body.messages;
    assert.deepEqual(h.map(m => m.text), ['one', 'two', 'three', 'reply']);
    const page = (await t.api('GET', `/api/dm/${b.id}?before=${h[2].id}&limit=1`, { token: a.token })).body.messages;
    assert.deepEqual(page.map(m => m.text), ['two']);
    assert.equal((await t.api('GET', `/api/dm/${a.id}`, { token: c.token })).status, 403);

    const room = (await t.api('POST', '/api/rooms', { token: a.token, body: { name: 'chat' } })).body.room;
    assert.equal((await t.api('GET', `/api/rooms/${room.id}/messages`, { token: c.token })).status, 403);
    assert.deepEqual((await t.api('GET', `/api/rooms/${room.id}/messages`, { token: a.token })).body.messages, []);
  } finally { await t.close(); }
});

test('chat is rate limited', async () => {
  const t = await start();
  try {
    const [a, b] = [await t.signup('ra1'), await t.signup('rb1')];
    await t.befriend(a, b);
    const codes = [];
    for (let i = 0; i < 14; i++) codes.push((await t.api('POST', `/api/dm/${b.id}`, { token: a.token, body: { text: `m${i}` } })).status);
    assert.ok(codes.includes(429));
    assert.equal(codes[0], 201);
  } finally { await t.close(); }
});

test('voice token: 503 when not configured, structurally valid when configured, members only', async () => {
  const off = await start();
  try {
    const a = await off.signup('user_va');
    const room = (await off.api('POST', '/api/rooms', { token: a.token, body: { name: 'v' } })).body.room;
    assert.equal((await off.api('POST', `/api/rooms/${room.id}/voice-token`, { token: a.token })).body.error, 'voice_not_configured');
  } finally { await off.close(); }

  const appId = '0123456789abcdef0123456789abcdef';
  const on = await start({ agoraAppId: appId, agoraCertificate: 'fedcba9876543210fedcba9876543210' });
  try {
    const [a, b] = [await on.signup('user_vb'), await on.signup('user_vc')];
    const room = (await on.api('POST', '/api/rooms', { token: a.token, body: { name: 'v' } })).body.room;
    assert.equal((await on.api('POST', `/api/rooms/${room.id}/voice-token`, { token: b.token })).status, 403);
    const r = await on.api('POST', `/api/rooms/${room.id}/voice-token`, { token: a.token });
    assert.equal(r.status, 200);
    assert.equal(r.body.channel, `room_${room.id}`);
    assert.equal(r.body.uid, a.id);
    assert.ok(r.body.token.startsWith('007'));
    const raw = zlib.inflateSync(Buffer.from(r.body.token.slice(3), 'base64'));
    assert.ok(raw.includes(Buffer.from(appId)) && raw.includes(Buffer.from(`room_${room.id}`)));
  } finally { await on.close(); }
});

test('token builder is deterministic for fixed inputs', () => {
  const a = buildRtcToken('0123456789abcdef0123456789abcdef', 'cert', 'ch', 5, 600, 1000, 42);
  const b = buildRtcToken('0123456789abcdef0123456789abcdef', 'cert', 'ch', 5, 600, 1000, 42);
  assert.equal(a, b);
  assert.notEqual(a, buildRtcToken('0123456789abcdef0123456789abcdef', 'cert2', 'ch', 5, 600, 1000, 42));
});

test('idle empty-of-online-users rooms are reaped', async () => {
  const t = await start();
  try {
    const a = await t.signup('user_ia');
    await t.api('POST', '/api/rooms', { token: a.token, body: { name: 'idle' } });
    assert.equal(t.app.hub.reapIdleRooms(1000, Date.now() + 5000), 1);
    assert.equal((await t.api('GET', '/api/rooms', { token: a.token })).body.rooms.length, 0);
  } finally { await t.close(); }
});
