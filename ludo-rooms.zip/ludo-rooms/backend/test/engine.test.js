import { test } from 'node:test';
import assert from 'node:assert/strict';
import * as L from '../src/engine/ludo.js';
import { lcg } from './helpers.js';

const two = () => L.newGame([{ userId: 1, name: 'a' }, { userId: 2, name: 'b' }]); // seats 0 and 2
const seq = (...vals) => { let i = 0; return () => (vals[i++] - 0.5) / 6; }; // rng producing dice values

test('seats: 2 players sit opposite, 4 players use all seats', () => {
  assert.deepEqual(two().players.map(p => p.seat), [0, 2]);
  const g4 = L.newGame([1, 2, 3, 4].map(i => ({ userId: i, name: 'x' })));
  assert.deepEqual(g4.players.map(p => p.seat), [0, 1, 2, 3]);
  assert.throws(() => L.newGame([{ userId: 1, name: 'a' }]));
});

test('a token only leaves base on a 6; otherwise the turn passes', () => {
  const g = two();
  L.roll(g, seq(3));
  assert.equal(g.event.type, 'no_move');
  assert.equal(g.turn, 1);
  L.roll(g, seq(6));
  assert.deepEqual(L.legalMoves(g), [0, 1, 2, 3]);
  L.move(g, 2);
  assert.equal(g.players[1].tokens[2], 0);
  assert.equal(g.turn, 1, 'six grants an extra turn');
  assert.equal(g.dice, null);
});

test('three sixes in a row forfeit the turn', () => {
  const g = two();
  L.roll(g, seq(6)); L.move(g, 0);
  L.roll(g, seq(6)); L.move(g, 0);
  L.roll(g, seq(6));
  assert.equal(g.event.type, 'three_sixes');
  assert.equal(g.turn, 1);
  assert.equal(g.dice, null);
});

test('capture on a normal square sends the opponent home', () => {
  const g = two();
  g.players[0].tokens = [3, -1, -1, -1];
  g.players[1].tokens = [31, -1, -1, -1]; // seat 2 start 26 -> abs 5
  g.dice = 2;
  L.move(g, 0);
  assert.equal(g.players[0].tokens[0], 5);
  assert.equal(g.players[1].tokens[0], -1);
  assert.equal(g.event.captured, 1);
});

test('no capture on a safe square', () => {
  const g = two();
  g.players[0].tokens = [6, -1, -1, -1];
  g.players[1].tokens = [34, -1, -1, -1]; // abs (26+34)%52 = 8 (safe)
  g.dice = 2;
  L.move(g, 0);
  assert.equal(g.players[1].tokens[0], 34);
  assert.equal(g.event.captured, 0);
});

test('exact roll needed to reach home; overshoot is illegal', () => {
  const g = two();
  g.players[0].tokens = [54, -1, -1, -1];
  g.dice = 3;
  assert.deepEqual(L.legalMoves(g), []);
  assert.throws(() => L.move(g, 0), /illegal_move/);
  g.dice = 2; L.move(g, 0);
  assert.equal(g.players[0].tokens[0], L.HOME);
});

test('finishing all tokens ends a 2-player game with a ranking', () => {
  const g = two();
  g.players[0].tokens = [56, 56, 56, 55];
  g.dice = 1;
  L.move(g, 3);
  assert.equal(g.status, 'finished');
  assert.deepEqual(g.finished, [1, 2]);
});

test('leaving mid-game ends it when one player remains', () => {
  const g = two();
  L.leave(g, 1);
  assert.equal(g.status, 'finished');
  assert.deepEqual(g.finished, [2]);
});

test('leaving on your own turn passes the turn in a 3-player game', () => {
  const g = L.newGame([1, 2, 3].map(i => ({ userId: i, name: 'x' })));
  L.leave(g, 1);
  assert.equal(g.status, 'playing');
  assert.equal(g.players[g.turn].userId, 2);
});

test('rolling twice or moving before rolling is rejected', () => {
  const g = two();
  assert.throws(() => L.move(g, 0), /roll_first/);
  L.roll(g, seq(6));
  assert.throws(() => L.roll(g, seq(1)), /must_move/);
});

test('200 random 4-player games always finish with valid positions', () => {
  for (let seed = 1; seed <= 200; seed++) {
    const rng = lcg(seed);
    const g = L.newGame([1, 2, 3, 4].map(i => ({ userId: i, name: 'x' })));
    let steps = 0;
    while (g.status === 'playing') {
      if (++steps > 20000) assert.fail(`game ${seed} did not finish`);
      if (g.dice === null) L.roll(g, rng);
      else { const legal = L.legalMoves(g); L.move(g, legal[Math.floor(rng() * legal.length)]); }
      for (const p of g.players) for (const t of p.tokens) assert.ok(t >= -1 && t <= 56);
    }
    assert.equal(g.finished.length, 4);
    assert.equal(new Set(g.finished).size, 4);
  }
});
