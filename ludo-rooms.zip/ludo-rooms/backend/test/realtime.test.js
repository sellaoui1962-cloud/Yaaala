import { test } from 'node:test';
import assert from 'node:assert/strict';
import { start } from './helpers.js';

test('websocket requires a valid token', async () => {
  const t = await start();
  try {
    const ws = new WebSocket(`ws://127.0.0.1:${t.port}/ws?token=garbage`);
    const outcome = await new Promise(res => { ws.onopen = () => res('open'); ws.onerror = () => res('rejected'); ws.onclose = () => res('rejected'); });
    assert.equal(outcome, 'rejected');
  } finally { await t.close(); }
});

test('presence reaches friends; room chat and membership are broadcast', async () => {
  const t = await start();
  try {
    const a = await t.signup('alpha'), b = await t.signup('bravo'), c = await t.signup('charlie');
    await t.befriend(a, b);
    const ca = await t.connect(a);
    await ca.next(m => m.t === 'hello');
    const cb = await t.connect(b);
    const p = await ca.next(m => m.t === 'presence' && m.userId === b.id);
    assert.equal(p.online, true);
    assert.equal((await t.api('GET', '/api/friends', { token: a.token })).body.friends[0].online, true);

    const room = (await t.api('POST', '/api/rooms', { token: a.token, body: { name: 'live', maxPlayers: 2 } })).body.room;
    const st = await ca.next(m => m.t === 'room.state');
    assert.equal(st.room.id, room.id);
    await t.api('POST', `/api/rooms/${room.id}/join`, { token: b.token });
    const st2 = await ca.next(m => m.t === 'room.state' && m.room.memberCount === 2);
    assert.deepEqual(st2.room.members.map(m => m.online), [true, true]);

    cb.send({ t: 'chat.send', text: 'hello room' });
    const m1 = await ca.next(m => m.t === 'chat.message');
    assert.equal(m1.message.text, 'hello room');
    assert.equal(m1.message.senderName, 'BRAVO');
    assert.equal((await t.api('GET', `/api/rooms/${room.id}/messages`, { token: a.token })).body.messages.length, 1);

    const cc = await t.connect(c);          // not a member: cannot chat in the room
    cc.send({ t: 'chat.send', text: 'sneak' });
    assert.equal((await cc.next(m => m.t === 'error')).code, 'not_member');

    cb.send({ t: 'dm.send', to: a.id, text: 'psst' });
    assert.equal((await ca.next(m => m.t === 'dm.message')).message.text, 'psst');
    assert.equal((await cb.next(m => m.t === 'dm.message')).message.text, 'psst');
    cc.send({ t: 'dm.send', to: a.id, text: 'spam' });
    assert.equal((await cc.next(m => m.t === 'error')).code, 'not_friends');

    cb.close();
    const off = await ca.next(m => m.t === 'presence' && m.userId === b.id);
    assert.equal(off.online, false);
    ca.close(); cc.close();
  } finally { await t.close(); }
});

test('voice state is shared with room members', async () => {
  const t = await start();
  try {
    const a = await t.signup('vox_a'), b = await t.signup('vox_b');
    const ca = await t.connect(a), cb = await t.connect(b);
    const room = (await t.api('POST', '/api/rooms', { token: a.token, body: { name: 'voice' } })).body.room;
    await t.api('POST', `/api/rooms/${room.id}/join`, { token: b.token });
    cb.send({ t: 'voice.state', inVoice: true, muted: true });
    const st = await ca.next(m => m.t === 'room.state' && m.room.members.some(x => x.inVoice));
    const me = st.room.members.find(x => x.id === b.id);
    assert.equal(me.muted, true);
    cb.send({ t: 'voice.state', inVoice: false });
    const st2 = await ca.next(m => m.t === 'room.state' && m.room.members.every(x => !x.inVoice));
    assert.ok(st2);
    ca.close(); cb.close();
  } finally { await t.close(); }
});

test('full 2-player game over websockets with turn enforcement, resume after reconnect', async () => {
  const t = await start();
  try {
    const a = await t.signup('gamer_a'), b = await t.signup('gamer_b');
    const room = (await t.api('POST', '/api/rooms', { token: a.token, body: { name: 'match', maxPlayers: 2 } })).body.room;
    await t.api('POST', `/api/rooms/${room.id}/join`, { token: b.token });
    let ca = await t.connect(a); const cb = await t.connect(b);
    const clients = { [a.id]: ca, [b.id]: cb };

    cb.send({ t: 'game.start' });
    assert.equal((await cb.next(m => m.t === 'error')).code, 'owner_only');
    ca.send({ t: 'game.start' });
    let g = (await ca.next(m => m.t === 'game.state')).game;
    assert.equal(g.status, 'playing');
    assert.equal(g.players.length, 2);

    // joining a running game is refused
    const late = await t.signup('late_one');
    assert.equal((await t.api('POST', `/api/rooms/${room.id}/join`, { token: late.token })).body.error, 'room_full');

    // out-of-turn action is rejected
    const waiting = g.players[1 - g.turn].userId, mover = g.players[g.turn].userId;
    clients[waiting].send({ t: 'game.roll' });
    assert.equal((await clients[waiting].next(m => m.t === 'error')).code, 'not_your_turn');
    clients[mover].send({ t: 'game.move', token: 0 });
    assert.equal((await clients[mover].next(m => m.t === 'error')).code, 'roll_first');

    let moves = 0, reconnected = false;
    while (g.status === 'playing') {
      if (++moves > 6000) assert.fail('game did not finish');
      const uid = g.players[g.turn].userId;
      const c = clients[uid];
      const prev = g.version;
      if (g.dice === null) c.send({ t: 'game.roll' });
      else c.send({ t: 'game.move', token: g.legal.reduce((best, i) => (g.players[g.turn].tokens[i] > g.players[g.turn].tokens[best] ? i : best), g.legal[0]) });
      const nextGame = await ca.next(m => m.t === 'game.state' && m.game.version > prev).catch(() => null);
      if (!nextGame) { g = { ...g }; continue; }
      g = nextGame.game;
      if (!reconnected && moves === 40 && g.status === 'playing') { // drop & resume: state must be replayed
        reconnected = true;
        ca.close(); await new Promise(r => setTimeout(r, 50));
        ca = await t.connect(a); clients[a.id] = ca;
        const resumed = await ca.next(m => m.t === 'game.state');
        assert.equal(resumed.game.version, g.version);
        assert.deepEqual(resumed.game.players.map(p => p.tokens), g.players.map(p => p.tokens));
      }
    }
    assert.equal(g.status, 'finished');
    assert.equal(g.finished.length, 2);
    assert.ok(reconnected, 'reconnect path was exercised');
    const rv = (await t.api('GET', `/api/rooms/${room.id}`, { token: a.token })).body.room;
    assert.equal(rv.gameStatus, 'finished');
    ca.close(); cb.close();
  } finally { await t.close(); }
});

test('game state survives a server restart (persisted in SQLite)', async () => {
  const dbPath = `/tmp/ludo-test-${Date.now()}.db`;
  const t1 = await start({ dbPath });
  const a = await t1.signup('persist_a'), b = await t1.signup('persist_b');
  const room = (await t1.api('POST', '/api/rooms', { token: a.token, body: { name: 'p', maxPlayers: 2 } })).body.room;
  await t1.api('POST', `/api/rooms/${room.id}/join`, { token: b.token });
  const ca = await t1.connect(a);
  ca.send({ t: 'game.start' });
  const g1 = (await ca.next(m => m.t === 'game.state')).game;
  ca.close();
  await t1.close();

  const { createApp } = await import('../src/app.js');
  const app2 = createApp({ dbPath });
  try {
    const g2 = app2.hub.getGame(room.id);
    assert.equal(g2.version, g1.version);
    assert.equal(g2.players.length, 2);
    assert.equal(app2.hub.roomView(room.id).memberCount, 2);
  } finally { await app2.close(); }
});
