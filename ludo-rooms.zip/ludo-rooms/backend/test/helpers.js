import { createApp } from '../src/app.js';

export function lcg(seed = 1) { // deterministic rng
  let s = seed >>> 0;
  return () => { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return s / 4294967296; };
}

export async function start(config = {}) {
  const app = createApp({ rng: lcg(7), ...config });
  const port = await app.listen(0);
  const base = `http://127.0.0.1:${port}`;
  const api = async (method, path, { body, token } = {}) => {
    const res = await fetch(base + path, {
      method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: body ? JSON.stringify(body) : undefined,
    });
    return { status: res.status, body: await res.json() };
  };
  let n = 0;
  const signup = async (name) => {
    const username = name || `user${++n}`;
    const r = await api('POST', '/api/auth/register', { body: { username, password: 'password123', displayName: username.toUpperCase() } });
    if (r.status !== 201) throw new Error('signup failed ' + JSON.stringify(r));
    return { ...r.body, id: r.body.user.id, token: r.body.accessToken, username };
  };
  const befriend = async (a, b) => {
    await api('POST', '/api/friends/request', { token: a.token, body: { username: b.username } });
    return api('POST', '/api/friends/accept', { token: b.token, body: { userId: a.id } });
  };
  const connect = (user) => new Promise((resolve, reject) => {
    const ws = new WebSocket(`ws://127.0.0.1:${port}/ws?token=${user.token}`);
    const inbox = []; const waiters = [];
    const c = { ws, inbox, last: {},
      send: obj => ws.send(JSON.stringify(obj)),
      next: (pred, ms = 3000) => new Promise((res, rej) => {
        const hit = inbox.findIndex(pred);
        if (hit >= 0) return res(inbox.splice(hit, 1)[0]);
        const w = { pred, res, t: setTimeout(() => rej(new Error('timeout waiting for message')), ms) };
        waiters.push(w);
      }),
      close: () => ws.close() };
    ws.onmessage = e => {
      const m = JSON.parse(e.data);
      c.last[m.t] = m;
      const wi = waiters.findIndex(w => w.pred(m));
      if (wi >= 0) { const [w] = waiters.splice(wi, 1); clearTimeout(w.t); w.res(m); } else inbox.push(m);
    };
    ws.onopen = () => resolve(c);
    ws.onerror = () => reject(new Error('ws error'));
  });
  return { app, base, port, api, signup, befriend, connect, close: () => app.close() };
}
