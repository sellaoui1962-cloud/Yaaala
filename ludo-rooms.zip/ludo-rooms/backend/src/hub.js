import * as Ludo from './engine/ludo.js';

export class HttpError extends Error {
  constructor(status, code, message) { super(message || code); this.status = status; this.code = code; }
}

const SETTING_KEYS = Object.keys(Ludo.DEFAULT_SETTINGS);
const cleanSettings = (s = {}) => Object.fromEntries(
  SETTING_KEYS.filter(k => typeof s[k] === 'boolean').map(k => [k, s[k]]));

export function cleanText(text, max = 500) {
  const t = typeof text === 'string' ? text.trim() : '';
  if (!t || t.length > max) throw new HttpError(400, 'invalid_text', `text must be 1-${max} characters`);
  return t;
}

/** Rooms, game sessions, chat, presence and realtime fan-out. */
export class Hub {
  constructor(db, config = {}) {
    this.db = db;
    this.rng = config.rng || Math.random;
    this.conns = new Map();   // userId -> Set<WSConn>
    this.games = new Map();   // roomId -> game state
    this.voice = new Map();   // userId -> { muted }
    this.buckets = new Map(); // userId -> { tokens, ts }
  }

  // ---------- presence / transport ----------
  isOnline(uid) { return (this.conns.get(uid)?.size || 0) > 0; }

  sendTo(uid, obj) {
    const s = JSON.stringify(obj);
    for (const c of this.conns.get(uid) || []) c.send(s);
  }

  sendRoom(roomId, obj) {
    const s = JSON.stringify(obj);
    for (const set of this.conns.values()) for (const c of set) if (c.roomId === roomId) c.send(s);
  }

  friendIds(uid) {
    return this.db.prepare(
      `SELECT CASE WHEN user_id=? THEN friend_id ELSE user_id END AS id
       FROM friendships WHERE status='accepted' AND (user_id=? OR friend_id=?)`).all(uid, uid, uid).map(r => r.id);
  }

  areFriends(a, b) {
    return !!this.db.prepare(
      `SELECT 1 FROM friendships WHERE status='accepted' AND
       ((user_id=? AND friend_id=?) OR (user_id=? AND friend_id=?))`).get(a, b, b, a);
  }

  presence(uid, online) {
    for (const f of this.friendIds(uid)) this.sendTo(f, { t: 'presence', userId: uid, online });
  }

  attach(conn, userId) {
    conn.userId = userId; conn.roomId = null;
    const first = !this.isOnline(userId);
    if (!this.conns.has(userId)) this.conns.set(userId, new Set());
    this.conns.get(userId).add(conn);
    conn.on('message', text => this.onMessage(conn, text));
    conn.on('close', () => this.detach(conn));
    conn.send(JSON.stringify({ t: 'hello', userId }));
    const rid = this.roomIdOf(userId);
    if (rid) this.syncConn(conn, rid);
    if (first) this.presence(userId, true);
  }

  detach(conn) {
    const set = this.conns.get(conn.userId);
    if (!set) return;
    set.delete(conn);
    if (set.size > 0) return;
    this.conns.delete(conn.userId);
    this.db.prepare('UPDATE users SET last_seen=? WHERE id=?').run(Date.now(), conn.userId);
    const rid = this.roomIdOf(conn.userId);
    this.voice.delete(conn.userId);
    if (rid) { this.touch(rid); this.broadcastRoom(rid); }
    this.presence(conn.userId, false);
  }

  syncConn(conn, roomId) {
    conn.roomId = roomId;
    const rv = this.roomView(roomId);
    if (rv) conn.send(JSON.stringify({ t: 'room.state', room: rv }));
    const g = this.getGame(roomId);
    if (g) conn.send(JSON.stringify({ t: 'game.state', roomId, game: Ludo.view(g) }));
  }

  allow(uid) { // chat/DM only: 10 messages burst, refills 1/second
    const now = Date.now();
    const b = this.buckets.get(uid) || { tokens: 10, ts: now };
    b.tokens = Math.min(10, b.tokens + (now - b.ts) / 1000); b.ts = now;
    this.buckets.set(uid, b);
    if (b.tokens < 1) return false;
    b.tokens -= 1; return true;
  }

  onMessage(conn, text) {
    let m;
    try { m = JSON.parse(text); } catch { return conn.send(JSON.stringify({ t: 'error', code: 'bad_json' })); }
    try {
      switch (m.t) {
        case 'ping': conn.send('{"t":"pong"}'); break;
        case 'room.subscribe': {
          const rid = this.roomIdOf(conn.userId);
          if (!rid || rid !== m.roomId) throw new HttpError(403, 'not_member');
          this.syncConn(conn, rid); break;
        }
        case 'game.start': this.startGame(conn.userId); break;
        case 'game.roll': this.doRoll(conn.userId); break;
        case 'game.move': this.doMove(conn.userId, m.token); break;
        case 'chat.send': this.sendRoomChat(conn.userId, m.text); break;
        case 'dm.send': this.sendDm(conn.userId, m.to, m.text); break;
        case 'voice.state': this.setVoice(conn.userId, m); break;
        default: throw new HttpError(400, 'unknown_type');
      }
    } catch (e) {
      if (!(e instanceof HttpError)) throw e;
      conn.send(JSON.stringify({ t: 'error', code: e.code, ref: m.t }));
    }
  }

  // ---------- rooms ----------
  roomIdOf(uid) { return this.db.prepare('SELECT room_id FROM room_members WHERE user_id=?').get(uid)?.room_id ?? null; }
  roomRow(id) { return this.db.prepare("SELECT * FROM rooms WHERE id=? AND status='open'").get(id); }
  touch(roomId) { this.db.prepare('UPDATE rooms SET last_active=? WHERE id=?').run(Date.now(), roomId); }

  canView(uid, room) {
    return !room.is_private || room.owner_id === uid || this.roomIdOf(uid) === room.id || this.areFriends(uid, room.owner_id);
  }

  members(roomId) {
    return this.db.prepare(
      `SELECT u.id, u.username, u.display_name AS dn FROM room_members m JOIN users u ON u.id=m.user_id
       WHERE m.room_id=? ORDER BY m.joined_at, u.id`).all(roomId);
  }

  roomView(roomId) {
    const r = this.roomRow(roomId);
    if (!r) return null;
    const g = this.getGame(roomId);
    const members = this.members(roomId).map(m => ({
      id: m.id, username: m.username, displayName: m.dn, online: this.isOnline(m.id),
      inVoice: this.voice.has(m.id), muted: !!this.voice.get(m.id)?.muted,
      seat: g && g.status === 'playing' ? (g.players.find(p => p.userId === m.id)?.seat ?? null) : null,
    }));
    const owner = this.db.prepare('SELECT display_name FROM users WHERE id=?').get(r.owner_id);
    return {
      id: r.id, name: r.name, ownerId: r.owner_id, ownerName: owner?.display_name ?? '',
      isPrivate: !!r.is_private, maxPlayers: r.max_players, settings: JSON.parse(r.settings),
      memberCount: members.length, onlineCount: members.filter(m => m.online).length,
      gameStatus: g ? g.status : 'lobby', members,
    };
  }

  broadcastRoom(roomId) {
    const rv = this.roomView(roomId);
    if (rv) this.sendRoom(roomId, { t: 'room.state', room: rv });
  }

  listRooms(uid, q = '', limit = 30) {
    const ids = this.db.prepare(
      `SELECT id FROM rooms WHERE status='open' AND is_private=0 AND (?='' OR instr(lower(name), lower(?))>0)
       ORDER BY last_active DESC LIMIT ?`).all(q, q, Math.min(Math.max(limit, 1), 50)).map(r => r.id);
    return ids.map(id => this.roomView(id)).filter(r => r && r.memberCount > 0)
      .sort((a, b) => b.onlineCount - a.onlineCount);
  }

  createRoom(uid, { name, isPrivate = false, maxPlayers = 4, settings = {} }) {
    const n = typeof name === 'string' ? name.trim() : '';
    if (n.length < 1 || n.length > 40) throw new HttpError(400, 'invalid_name');
    if (!Number.isInteger(maxPlayers) || maxPlayers < 2 || maxPlayers > 4) throw new HttpError(400, 'invalid_max_players');
    if (this.roomIdOf(uid)) this.leaveRoom(uid);
    const now = Date.now();
    const id = Number(this.db.prepare(
      `INSERT INTO rooms(name,owner_id,is_private,max_players,settings,created_at,last_active) VALUES (?,?,?,?,?,?,?)`)
      .run(n, uid, isPrivate ? 1 : 0, maxPlayers, JSON.stringify({ ...Ludo.DEFAULT_SETTINGS, ...cleanSettings(settings) }), now, now).lastInsertRowid);
    this.addMember(uid, id);
    return this.roomView(id);
  }

  addMember(uid, roomId) {
    this.db.prepare('INSERT INTO room_members(user_id,room_id,joined_at) VALUES (?,?,?)').run(uid, roomId, Date.now());
    this.touch(roomId);
    for (const c of this.conns.get(uid) || []) this.syncConn(c, roomId);
    this.broadcastRoom(roomId);
  }

  joinRoom(uid, roomId) {
    const room = this.roomRow(roomId);
    if (!room) throw new HttpError(404, 'room_not_found');
    if (!this.canView(uid, room)) throw new HttpError(403, 'forbidden');
    if (this.roomIdOf(uid) === roomId) return this.roomView(roomId);
    const count = this.members(roomId).length;
    if (count >= room.max_players) throw new HttpError(409, 'room_full');
    const g = this.getGame(roomId);
    if (g && g.status === 'playing') throw new HttpError(409, 'game_in_progress');
    if (this.roomIdOf(uid)) this.leaveRoom(uid);
    this.addMember(uid, roomId);
    return this.roomView(roomId);
  }

  leaveRoom(uid) {
    const rid = this.roomIdOf(uid);
    if (!rid) return;
    this.db.prepare('DELETE FROM room_members WHERE user_id=?').run(uid);
    this.voice.delete(uid);
    for (const c of this.conns.get(uid) || []) { c.roomId = null; c.send(JSON.stringify({ t: 'room.left', roomId: rid })); }
    const g = this.getGame(rid);
    if (g && g.status === 'playing') {
      Ludo.leave(g, uid); this.saveGame(rid, g);
      this.sendRoom(rid, { t: 'game.state', roomId: rid, game: Ludo.view(g) });
    }
    const rest = this.members(rid);
    if (rest.length === 0) {
      this.db.prepare("UPDATE rooms SET status='closed' WHERE id=?").run(rid);
      this.games.delete(rid);
      return;
    }
    const room = this.db.prepare('SELECT owner_id FROM rooms WHERE id=?').get(rid);
    if (room.owner_id === uid) this.db.prepare('UPDATE rooms SET owner_id=? WHERE id=?').run(rest[0].id, rid);
    this.touch(rid);
    this.broadcastRoom(rid);
  }

  updateRoom(uid, roomId, patch = {}) {
    const room = this.roomRow(roomId);
    if (!room) throw new HttpError(404, 'room_not_found');
    if (room.owner_id !== uid) throw new HttpError(403, 'owner_only');
    const g = this.getGame(roomId);
    if (g && g.status === 'playing') throw new HttpError(409, 'game_in_progress');
    const settings = { ...JSON.parse(room.settings), ...cleanSettings(patch.settings) };
    let max = room.max_players;
    if (patch.maxPlayers !== undefined) {
      if (!Number.isInteger(patch.maxPlayers) || patch.maxPlayers < 2 || patch.maxPlayers > 4) throw new HttpError(400, 'invalid_max_players');
      if (patch.maxPlayers < this.members(roomId).length) throw new HttpError(409, 'too_many_members');
      max = patch.maxPlayers;
    }
    const priv = patch.isPrivate === undefined ? room.is_private : (patch.isPrivate ? 1 : 0);
    this.db.prepare('UPDATE rooms SET settings=?, max_players=?, is_private=? WHERE id=?')
      .run(JSON.stringify(settings), max, priv, roomId);
    this.broadcastRoom(roomId);
    return this.roomView(roomId);
  }

  reapIdleRooms(maxIdleMs = 10 * 60 * 1000, now = Date.now()) {
    const stale = this.db.prepare("SELECT id FROM rooms WHERE status='open' AND last_active < ?").all(now - maxIdleMs);
    let n = 0;
    for (const { id } of stale) {
      if (this.members(id).some(m => this.isOnline(m.id))) continue;
      this.db.prepare('DELETE FROM room_members WHERE room_id=?').run(id);
      this.db.prepare("UPDATE rooms SET status='closed' WHERE id=?").run(id);
      this.games.delete(id); n++;
    }
    return n;
  }

  // ---------- game ----------
  getGame(roomId) {
    if (this.games.has(roomId)) return this.games.get(roomId);
    const row = this.db.prepare('SELECT state FROM games WHERE room_id=?').get(roomId);
    if (!row) return null;
    const g = JSON.parse(row.state);
    this.games.set(roomId, g);
    return g;
  }

  saveGame(roomId, g) {
    this.games.set(roomId, g);
    this.db.prepare(`INSERT INTO games(room_id,state,updated_at) VALUES (?,?,?)
      ON CONFLICT(room_id) DO UPDATE SET state=excluded.state, updated_at=excluded.updated_at`)
      .run(roomId, JSON.stringify(g), Date.now());
    this.touch(roomId);
  }

  broadcastGame(roomId, g) {
    this.sendRoom(roomId, { t: 'game.state', roomId, game: Ludo.view(g) });
    this.broadcastRoom(roomId);
  }

  startGame(uid) {
    const rid = this.roomIdOf(uid);
    if (!rid) throw new HttpError(403, 'not_member');
    const room = this.roomRow(rid);
    if (room.owner_id !== uid) throw new HttpError(403, 'owner_only');
    const existing = this.getGame(rid);
    if (existing && existing.status === 'playing') throw new HttpError(409, 'game_in_progress');
    const ms = this.members(rid);
    if (ms.length < 2) throw new HttpError(409, 'need_two_players');
    const g = Ludo.newGame(ms.map(m => ({ userId: m.id, name: m.dn })), JSON.parse(room.settings));
    this.saveGame(rid, g);
    this.broadcastGame(rid, g);
    return g;
  }

  playing(uid) {
    const rid = this.roomIdOf(uid);
    if (!rid) throw new HttpError(403, 'not_member');
    const g = this.getGame(rid);
    if (!g || g.status !== 'playing') throw new HttpError(409, 'game_not_playing');
    if (Ludo.currentUserId(g) !== uid) throw new HttpError(409, 'not_your_turn');
    return [rid, g];
  }

  doRoll(uid) {
    const [rid, g] = this.playing(uid);
    if (g.dice !== null) throw new HttpError(409, 'must_move');
    Ludo.roll(g, this.rng);
    this.saveGame(rid, g); this.broadcastGame(rid, g);
  }

  doMove(uid, token) {
    const [rid, g] = this.playing(uid);
    if (!Number.isInteger(token)) throw new HttpError(400, 'invalid_token');
    try { Ludo.move(g, token); } catch (e) { throw new HttpError(409, e.message); }
    this.saveGame(rid, g); this.broadcastGame(rid, g);
  }

  // ---------- chat ----------
  msgView(row) {
    return { id: row.id, roomId: row.room_id, senderId: row.sender_id, senderName: row.dn,
             recipientId: row.recipient_id, text: row.text, createdAt: row.created_at };
  }

  insertMessage(roomId, from, to, text) {
    const id = Number(this.db.prepare('INSERT INTO messages(room_id,sender_id,recipient_id,text,created_at) VALUES (?,?,?,?,?)')
      .run(roomId, from, to, text, Date.now()).lastInsertRowid);
    return this.msgView(this.db.prepare(
      'SELECT m.*, u.display_name AS dn FROM messages m JOIN users u ON u.id=m.sender_id WHERE m.id=?').get(id));
  }

  sendRoomChat(uid, text) {
    if (!this.allow(uid)) throw new HttpError(429, 'rate_limited');
    const rid = this.roomIdOf(uid);
    if (!rid) throw new HttpError(403, 'not_member');
    const msg = this.insertMessage(rid, uid, null, cleanText(text));
    this.touch(rid);
    this.sendRoom(rid, { t: 'chat.message', message: msg });
    return msg;
  }

  sendDm(uid, to, text) {
    if (!this.allow(uid)) throw new HttpError(429, 'rate_limited');
    if (!Number.isInteger(to) || to === uid) throw new HttpError(400, 'invalid_recipient');
    if (!this.areFriends(uid, to)) throw new HttpError(403, 'not_friends');
    const msg = this.insertMessage(null, uid, to, cleanText(text));
    this.sendTo(uid, { t: 'dm.message', message: msg });
    this.sendTo(to, { t: 'dm.message', message: msg });
    return msg;
  }

  roomHistory(uid, roomId, before, limit = 50) {
    if (this.roomIdOf(uid) !== roomId) throw new HttpError(403, 'not_member');
    const rows = this.db.prepare(
      `SELECT m.*, u.display_name AS dn FROM messages m JOIN users u ON u.id=m.sender_id
       WHERE m.room_id=? AND (? IS NULL OR m.id<?) ORDER BY m.id DESC LIMIT ?`)
      .all(roomId, before ?? null, before ?? null, Math.min(Math.max(limit, 1), 100));
    return rows.reverse().map(r => this.msgView(r));
  }

  dmHistory(uid, other, before, limit = 50) {
    if (!this.areFriends(uid, other)) throw new HttpError(403, 'not_friends');
    const rows = this.db.prepare(
      `SELECT m.*, u.display_name AS dn FROM messages m JOIN users u ON u.id=m.sender_id
       WHERE m.room_id IS NULL AND ((m.sender_id=? AND m.recipient_id=?) OR (m.sender_id=? AND m.recipient_id=?))
       AND (? IS NULL OR m.id<?) ORDER BY m.id DESC LIMIT ?`)
      .all(uid, other, other, uid, before ?? null, before ?? null, Math.min(Math.max(limit, 1), 100));
    return rows.reverse().map(r => this.msgView(r));
  }

  // ---------- voice ----------
  setVoice(uid, { inVoice, muted }) {
    const rid = this.roomIdOf(uid);
    if (!rid) throw new HttpError(403, 'not_member');
    if (inVoice) this.voice.set(uid, { muted: !!muted }); else this.voice.delete(uid);
    this.broadcastRoom(rid);
  }
}
