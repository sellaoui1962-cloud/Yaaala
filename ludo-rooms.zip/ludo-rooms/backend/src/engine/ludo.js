// Server-authoritative Ludo rules. Pure functions; state is plain JSON.
//
// Token progress p: -1 = in base, 0..50 = on the shared 52-square track
// (absolute square = (START[seat] + p) % 52), 51..55 = home lane, 56 = home (finished).
export const TRACK = 52;
export const HOME = 56;
export const START = [0, 13, 26, 39];
export const SAFE = new Set([0, 8, 13, 21, 26, 34, 39, 47]);
export const DEFAULT_SETTINGS = { extraTurnOnSix: true, extraTurnOnCapture: false, safeSquares: true };

export const seatsFor = n => (n === 2 ? [0, 2] : n === 3 ? [0, 1, 2] : [0, 1, 2, 3]);
export const absSquare = (seat, p) => (START[seat] + p) % TRACK;

export function newGame(users, settings = {}) {
  if (users.length < 2 || users.length > 4) throw new Error('2-4 players required');
  const seats = seatsFor(users.length);
  return {
    status: 'playing',
    version: 0,
    settings: { ...DEFAULT_SETTINGS, ...settings },
    players: users.map((u, i) => ({
      seat: seats[i], userId: u.userId, name: u.name,
      tokens: [-1, -1, -1, -1], left: false,
    })),
    turn: 0, dice: null, sixes: 0, finished: [], event: { type: 'start' },
  };
}

export function legalMoves(state) {
  if (state.status !== 'playing' || state.dice === null) return [];
  const p = state.players[state.turn];
  const out = [];
  p.tokens.forEach((t, i) => {
    if (t === -1) { if (state.dice === 6) out.push(i); }
    else if (t < HOME && t + state.dice <= HOME) out.push(i);
  });
  return out;
}

const active = (state, i) => !state.players[i].left && !state.finished.includes(state.players[i].userId);

function advance(state) {
  state.dice = null; state.sixes = 0;
  const n = state.players.length;
  for (let k = 1; k <= n; k++) {
    const i = (state.turn + k) % n;
    if (active(state, i)) { state.turn = i; return; }
  }
}

function checkEnd(state) {
  const alive = state.players.filter((_, i) => active(state, i));
  if (alive.length <= 1) {
    if (alive.length === 1) state.finished.push(alive[0].userId);
    state.status = 'finished'; state.dice = null;
    return true;
  }
  return false;
}

export function currentUserId(state) { return state.players[state.turn].userId; }

export function roll(state, rng = Math.random) {
  if (state.status !== 'playing') throw new Error('game_not_playing');
  if (state.dice !== null) throw new Error('must_move');
  const d = 1 + Math.floor(rng() * 6);
  state.version++;
  if (d === 6) {
    state.sixes++;
    if (state.sixes >= 3) {
      state.event = { type: 'three_sixes', dice: d, userId: currentUserId(state) };
      advance(state); return state;
    }
  }
  state.dice = d;
  if (legalMoves(state).length === 0) {
    state.event = { type: 'no_move', dice: d, userId: currentUserId(state) };
    advance(state);
  } else {
    state.event = { type: 'roll', dice: d, userId: currentUserId(state) };
  }
  return state;
}

export function move(state, tokenIdx) {
  if (state.status !== 'playing') throw new Error('game_not_playing');
  if (state.dice === null) throw new Error('roll_first');
  if (!legalMoves(state).includes(tokenIdx)) throw new Error('illegal_move');
  const p = state.players[state.turn];
  const dice = state.dice;
  const from = p.tokens[tokenIdx];
  const to = from === -1 ? 0 : from + dice;
  p.tokens[tokenIdx] = to;
  state.version++;

  let captured = 0;
  if (to <= 50) {
    const sq = absSquare(p.seat, to);
    if (!(state.settings.safeSquares && SAFE.has(sq))) {
      for (const o of state.players) {
        if (o === p) continue;
        o.tokens = o.tokens.map(t => {
          if (t >= 0 && t <= 50 && absSquare(o.seat, t) === sq) { captured++; return -1; }
          return t;
        });
      }
    }
  }
  let justFinished = false;
  if (p.tokens.every(t => t === HOME)) { state.finished.push(p.userId); justFinished = true; }
  state.event = { type: 'move', userId: p.userId, token: tokenIdx, from, to, dice, captured, finishedPlayer: justFinished };

  if (checkEnd(state)) return state;
  const extra = !justFinished &&
    ((dice === 6 && state.settings.extraTurnOnSix) || (captured > 0 && state.settings.extraTurnOnCapture));
  if (extra) state.dice = null; else advance(state);
  return state;
}

export function leave(state, userId) {
  const i = state.players.findIndex(p => p.userId === userId);
  if (i < 0 || state.status !== 'playing') return state;
  state.players[i].left = true;
  state.version++;
  state.event = { type: 'left', userId };
  if (checkEnd(state)) return state;
  if (state.turn === i) advance(state);
  return state;
}

export const view = state => ({ ...state, legal: legalMoves(state) });
