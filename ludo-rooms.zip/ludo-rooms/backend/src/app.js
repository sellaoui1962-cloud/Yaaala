import http from 'node:http';
import { openDb } from './db.js';
import { Hub, HttpError, cleanText } from './hub.js';
import { acceptUpgrade } from './ws.js';
import { buildRtcToken } from './agora.js';
import {
  hashPassword, verifyPassword, signAccess, verifyAccess, sha256, newRefreshToken, getSecret,
} from './auth.js';

const ACCESS_TTL = 900;
const REFRESH_TTL_MS = 30 * 24 * 3600 * 1000;
const USERNAME_RE = /^[A-Za-z0-9_]{3,20}$/;

export function createApp(config = {}) {
  const db = openDb(config.dbPath || ':memory:');
  const secret = getSecret(db);
  const hub = new Hub(db, config);
  const fails = new Map(); // login throttle: key -> [timestamps]
  const routes = [];

  const route = (method, pattern, handler, { auth = true } = {}) => {
    const keys = [];
    const re = new RegExp('^' + pattern.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
    routes.push({ method, re, keys, handler, auth });
  };

  const userRow = id => db.prepare('SELECT id, username, display_name AS displayName FROM users WHERE id=?').get(id);
  const int = (v, name = 'id') => { const n = Number(v); if (!Number.isInteger(n) || n < 1) throw new HttpError(400, `invalid_${name}`); return n; };

  function issueSession(userId) {
    const refresh = newRefreshToken();
    db.prepare('INSERT INTO sessions(user_id,token_hash,expires_at,created_at) VALUES (?,?,?,?)')
      .run(userId, sha256(refresh), Date.now() + REFRESH_TTL_MS, Date.now());
    return { accessToken: signAccess(secret, userId, ACCESS_TTL), refreshToken: refresh, expiresIn: ACCESS_TTL, user: userRow(userId) };
  }

  // ---------- auth ----------
  route('POST', '/api/auth/register', ({ body }) => {
    const { username, password } = body;
    if (typeof username !== 'string' || !USERNAME_RE.test(username)) throw new HttpError(400, 'invalid_username', '3-20 letters, digits or _');
    if (typeof password !== 'string' || password.length < 8 || password.length > 128) throw new HttpError(400, 'invalid_password', 'min 8 characters');
    const dn = typeof body.displayName === 'string' && body.displayName.trim() ? body.displayName.trim().slice(0, 30) : username;
    if (db.prepare('SELECT 1 FROM users WHERE username=?').get(username)) throw new HttpError(409, 'username_taken');
    const id = Number(db.prepare('INSERT INTO users(username,display_name,pass_hash,created_at) VALUES (?,?,?,?)')
      .run(username, dn, hashPassword(password), Date.now()).lastInsertRowid);
    return [201, issueSession(id)];
  }, { auth: false });

  route('POST', '/api/auth/login', ({ body, req }) => {
    const { username, password } = body;
    const key = `${req.socket.remoteAddress}|${String(username).toLowerCase()}`;
    const recent = (fails.get(key) || []).filter(t => Date.now() - t < 60_000);
    if (recent.length >= 5) throw new HttpError(429, 'too_many_attempts');
    const u = typeof username === 'string' ? db.prepare('SELECT * FROM users WHERE username=?').get(username) : null;
    if (!u || typeof password !== 'string' || !verifyPassword(password, u.pass_hash)) {
      recent.push(Date.now()); fails.set(key, recent);
      throw new HttpError(401, 'invalid_credentials');
    }
    fails.delete(key);
    return issueSession(u.id);
  }, { auth: false });

  route('POST', '/api/auth/refresh', ({ body }) => {
    const h = sha256(String(body.refreshToken));
    const s = db.prepare('SELECT * FROM sessions WHERE token_hash=?').get(h);
    if (!s || s.expires_at < Date.now()) throw new HttpError(401, 'invalid_refresh');
    db.prepare('DELETE FROM sessions WHERE id=?').run(s.id); // rotate
    return issueSession(s.user_id);
  }, { auth: false });

  route('POST', '/api/auth/logout', ({ body }) => {
    db.prepare('DELETE FROM sessions WHERE token_hash=?').run(sha256(String(body.refreshToken)));
    return { ok: true };
  }, { auth: false });

  route('GET', '/api/me', ({ userId }) => ({ user: userRow(userId), roomId: hub.roomIdOf(userId) }));

  // ---------- friends ----------
  const relationOf = (me, other) => {
    const r = db.prepare('SELECT * FROM friendships WHERE (user_id=? AND friend_id=?) OR (user_id=? AND friend_id=?)').get(me, other, other, me);
    if (!r) return 'none';
    if (r.status === 'accepted') return 'friend';
    return r.user_id === me ? 'pending_out' : 'pending_in';
  };

  function friendActivity(me, f) {
    const row = db.prepare('SELECT room_id FROM room_members WHERE user_id=?').get(f);
    const base = { ...userRow(f), online: hub.isOnline(f), roomId: null, roomName: null, canJoin: false };
    if (!row) return base;
    const room = hub.roomRow(row.room_id);
    if (!room || !hub.canView(me, room)) return base; // private rooms stay hidden unless authorized
    const rv = hub.roomView(room.id);
    return { ...base, roomId: room.id, roomName: room.name,
             canJoin: rv.memberCount < rv.maxPlayers && rv.gameStatus !== 'playing' };
  }

  route('GET', '/api/friends', ({ userId }) => {
    const friends = hub.friendIds(userId).map(f => friendActivity(userId, f))
      .sort((a, b) => Number(b.online) - Number(a.online) || a.displayName.localeCompare(b.displayName));
    const incoming = db.prepare(`SELECT u.id, u.username, u.display_name AS displayName FROM friendships f JOIN users u ON u.id=f.user_id
      WHERE f.friend_id=? AND f.status='pending'`).all(userId);
    const outgoing = db.prepare(`SELECT u.id, u.username, u.display_name AS displayName FROM friendships f JOIN users u ON u.id=f.friend_id
      WHERE f.user_id=? AND f.status='pending'`).all(userId);
    return { friends, incoming, outgoing };
  });

  route('GET', '/api/users/search', ({ userId, query }) => {
    const q = String(query.q || '').trim();
    if (q.length < 2) return { users: [] };
    const rows = db.prepare(`SELECT id, username, display_name AS displayName FROM users
      WHERE id<>? AND (instr(lower(username), lower(?))>0 OR instr(lower(display_name), lower(?))>0) ORDER BY username LIMIT 20`)
      .all(userId, q, q);
    return { users: rows.map(u => ({ ...u, relation: relationOf(userId, u.id) })) };
  });

  route('POST', '/api/friends/request', ({ userId, body }) => {
    const other = db.prepare('SELECT id FROM users WHERE username=?').get(String(body.username));
    if (!other) throw new HttpError(404, 'user_not_found');
    if (other.id === userId) throw new HttpError(400, 'cannot_add_self');
    const rel = relationOf(userId, other.id);
    if (rel === 'friend') throw new HttpError(409, 'already_friends');
    if (rel === 'pending_out') throw new HttpError(409, 'already_requested');
    if (rel === 'pending_in') { // they already asked us: accept
      db.prepare("UPDATE friendships SET status='accepted' WHERE user_id=? AND friend_id=?").run(other.id, userId);
      return { relation: 'friend' };
    }
    db.prepare("INSERT INTO friendships(user_id,friend_id,status,created_at) VALUES (?,?, 'pending', ?)").run(userId, other.id, Date.now());
    hub.sendTo(other.id, { t: 'friend.request', from: userRow(userId) });
    return [201, { relation: 'pending_out' }];
  });

  route('POST', '/api/friends/accept', ({ userId, body }) => {
    const other = int(body.userId, 'user_id');
    const r = db.prepare("UPDATE friendships SET status='accepted' WHERE user_id=? AND friend_id=? AND status='pending'").run(other, userId);
    if (!r.changes) throw new HttpError(404, 'no_request');
    hub.sendTo(other, { t: 'friend.accepted', user: userRow(userId) });
    return { relation: 'friend' };
  });

  route('POST', '/api/friends/decline', ({ userId, body }) => {
    db.prepare("DELETE FROM friendships WHERE user_id=? AND friend_id=? AND status='pending'").run(int(body.userId, 'user_id'), userId);
    return { ok: true };
  });

  route('DELETE', '/api/friends/:id', ({ userId, params }) => {
    const o = int(params.id);
    db.prepare('DELETE FROM friendships WHERE (user_id=? AND friend_id=?) OR (user_id=? AND friend_id=?)').run(userId, o, o, userId);
    return { ok: true };
  });

  // ---------- rooms ----------
  route('GET', '/api/rooms', ({ userId, query }) => ({
    rooms: hub.listRooms(userId, String(query.q || '').trim().slice(0, 40), Number(query.limit) || 30),
  }));

  route('POST', '/api/rooms', ({ userId, body }) => [201, { room: hub.createRoom(userId, body) }]);

  route('GET', '/api/rooms/:id', ({ userId, params }) => {
    const room = hub.roomRow(int(params.id));
    if (!room) throw new HttpError(404, 'room_not_found');
    if (!hub.canView(userId, room)) throw new HttpError(403, 'forbidden');
    return { room: hub.roomView(room.id) };
  });

  route('POST', '/api/rooms/:id/join', ({ userId, params }) => ({ room: hub.joinRoom(userId, int(params.id)) }));
  route('POST', '/api/rooms/leave', ({ userId }) => { hub.leaveRoom(userId); return { ok: true }; });
  route('PATCH', '/api/rooms/:id', ({ userId, params, body }) => ({ room: hub.updateRoom(userId, int(params.id), body) }));

  route('GET', '/api/rooms/:id/messages', ({ userId, params, query }) => ({
    messages: hub.roomHistory(userId, int(params.id), query.before ? int(query.before, 'before') : null, Number(query.limit) || 50),
  }));

  route('POST', '/api/rooms/:id/voice-token', ({ userId, params }) => {
    const rid = int(params.id);
    if (hub.roomIdOf(userId) !== rid) throw new HttpError(403, 'not_member');
    if (!config.agoraAppId || !config.agoraCertificate) throw new HttpError(503, 'voice_not_configured');
    const channel = `room_${rid}`;
    return { appId: config.agoraAppId, channel, uid: userId, expiresIn: 3600,
             token: buildRtcToken(config.agoraAppId, config.agoraCertificate, channel, userId, 3600) };
  });

  // ---------- direct messages ----------
  route('GET', '/api/dm/:userId', ({ userId, params, query }) => ({
    messages: hub.dmHistory(userId, int(params.userId, 'user_id'), query.before ? int(query.before, 'before') : null, Number(query.limit) || 50),
  }));
  route('POST', '/api/dm/:userId', ({ userId, params, body }) =>
    [201, { message: hub.sendDm(userId, int(params.userId, 'user_id'), body.text) }]);

  route('GET', '/api/health', () => ({ ok: true, voice: !!(config.agoraAppId && config.agoraCertificate) }), { auth: false });

  // ---------- http plumbing ----------
  async function readBody(req) {
    if (req.method === 'GET' || req.method === 'DELETE') return {};
    let size = 0; const chunks = [];
    for await (const c of req) { size += c.length; if (size > 32 * 1024) throw new HttpError(413, 'payload_too_large'); chunks.push(c); }
    if (!chunks.length) return {};
    try { const v = JSON.parse(Buffer.concat(chunks).toString()); return v && typeof v === 'object' ? v : {}; }
    catch { throw new HttpError(400, 'bad_json'); }
  }

  const send = (res, status, obj) => {
    const s = JSON.stringify(obj);
    res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(s) });
    res.end(s);
  };

  const server = http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://x');
      const query = Object.fromEntries(url.searchParams);
      for (const r of routes) {
        if (r.method !== req.method) continue;
        const m = r.re.exec(url.pathname);
        if (!m) continue;
        const params = Object.fromEntries(r.keys.map((k, i) => [k, decodeURIComponent(m[i + 1])]));
        let userId = null;
        if (r.auth) {
          const h = req.headers.authorization || '';
          userId = verifyAccess(secret, h.startsWith('Bearer ') ? h.slice(7) : '');
          if (!userId || !userRow(userId)) throw new HttpError(401, 'unauthorized');
        }
        const out = await r.handler({ req, res, params, query, body: await readBody(req), userId });
        return Array.isArray(out) ? send(res, out[0], out[1]) : send(res, 200, out);
      }
      throw new HttpError(404, 'not_found');
    } catch (e) {
      if (e instanceof HttpError) return send(res, e.status, { error: e.code, message: e.message });
      console.error(e);
      send(res, 500, { error: 'internal' });
    }
  });

  server.on('upgrade', (req, socket) => {
    const url = new URL(req.url, 'http://x');
    const userId = url.pathname === '/ws' ? verifyAccess(secret, url.searchParams.get('token')) : null;
    if (!userId || !userRow(userId)) { socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n'); socket.destroy(); return; }
    const conn = acceptUpgrade(req, socket);
    if (conn) hub.attach(conn, userId);
  });

  const reaper = setInterval(() => hub.reapIdleRooms(), 60_000);
  reaper.unref();

  return {
    server, db, hub,
    listen: (port = 0) => new Promise(r => server.listen(port, () => r(server.address().port))),
    close: () => new Promise(r => {
      clearInterval(reaper);
      for (const set of hub.conns.values()) for (const c of set) c.close(1001);
      server.close(() => { db.close(); r(); });
      server.closeAllConnections?.();
    }),
  };
}
