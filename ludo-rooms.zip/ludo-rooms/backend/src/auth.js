import crypto from 'node:crypto';

const SCRYPT = { N: 16384, r: 8, p: 1 };

export function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const h = crypto.scryptSync(pw, salt, 32, SCRYPT);
  return `scrypt$${salt.toString('base64')}$${h.toString('base64')}`;
}

export function verifyPassword(pw, stored) {
  const [alg, s, h] = String(stored).split('$');
  if (alg !== 'scrypt' || !s || !h) return false;
  const exp = Buffer.from(h, 'base64');
  const got = crypto.scryptSync(pw, Buffer.from(s, 'base64'), exp.length, SCRYPT);
  return crypto.timingSafeEqual(exp, got);
}

const b64u = v => Buffer.from(v).toString('base64url');
const hmac = (secret, data) => crypto.createHmac('sha256', secret).update(data).digest('base64url');

export function signAccess(secret, userId, ttlSec = 900, nowMs = Date.now()) {
  const p = b64u(JSON.stringify({ sub: userId, exp: Math.floor(nowMs / 1000) + ttlSec }));
  return `${p}.${hmac(secret, p)}`;
}

export function verifyAccess(secret, token, nowMs = Date.now()) {
  if (typeof token !== 'string') return null;
  const [p, sig] = token.split('.');
  if (!p || !sig) return null;
  const a = Buffer.from(sig), b = Buffer.from(hmac(secret, p));
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try {
    const o = JSON.parse(Buffer.from(p, 'base64url').toString());
    return o.exp * 1000 > nowMs ? o.sub : null;
  } catch { return null; }
}

export const sha256 = s => crypto.createHash('sha256').update(s).digest('hex');
export const newRefreshToken = () => crypto.randomBytes(32).toString('base64url');

export function getSecret(db) {
  const row = db.prepare("SELECT value FROM meta WHERE key='jwt_secret'").get();
  if (row) return row.value;
  const v = crypto.randomBytes(32).toString('hex');
  db.prepare("INSERT INTO meta(key,value) VALUES('jwt_secret',?)").run(v);
  return v;
}
