// Agora AccessToken2 ("007") builder for an RTC publisher token.
// Needs YOUR OWN Agora project credentials (AGORA_APP_ID / AGORA_APP_CERTIFICATE).
// NOTE: structure is unit-tested locally, but has NOT been validated against Agora's servers.
import crypto from 'node:crypto';
import zlib from 'node:zlib';

const u16 = n => { const b = Buffer.alloc(2); b.writeUInt16LE(n); return b; };
const u32 = n => { const b = Buffer.alloc(4); b.writeUInt32LE(n >>> 0); return b; };
const str = s => { const d = Buffer.isBuffer(s) ? s : Buffer.from(String(s)); return Buffer.concat([u16(d.length), d]); };
const hmac = (key, msg) => crypto.createHmac('sha256', key).update(msg).digest();

export function buildRtcToken(appId, certificate, channel, uid, ttlSec = 3600,
                              issueTs = Math.floor(Date.now() / 1000),
                              salt = crypto.randomInt(1, 0x7fffffff)) {
  const privileges = [[1, ttlSec], [2, ttlSec]]; // join channel, publish audio
  const service = Buffer.concat([
    u16(1), u16(privileges.length),
    ...privileges.map(([k, e]) => Buffer.concat([u16(k), u32(e)])),
    str(channel), str(String(uid)),
  ]);
  const signingInfo = Buffer.concat([str(appId), u32(issueTs), u32(ttlSec), u32(salt), u16(1), service]);
  const signingKey = hmac(u32(salt), hmac(u32(issueTs), certificate));
  const signature = hmac(signingKey, signingInfo);
  return '007' + zlib.deflateSync(Buffer.concat([str(signature), signingInfo])).toString('base64');
}
