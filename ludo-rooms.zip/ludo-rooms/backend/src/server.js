import { createApp } from './app.js';

const app = createApp({
  dbPath: process.env.DB_PATH || './data/ludo.db',
  agoraAppId: process.env.AGORA_APP_ID || '',
  agoraCertificate: process.env.AGORA_APP_CERTIFICATE || '',
});
const port = await app.listen(Number(process.env.PORT) || 8080);
console.log(`Ludo Rooms backend listening on :${port} (voice ${process.env.AGORA_APP_ID ? 'enabled' : 'disabled'})`);
process.on('SIGINT', async () => { await app.close(); process.exit(0); });
