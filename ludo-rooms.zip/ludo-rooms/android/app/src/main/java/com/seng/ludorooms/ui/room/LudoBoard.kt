package com.seng.ludorooms.ui.room

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.seng.ludorooms.data.Game

/** Geometry of the 15x15 board. Must stay consistent with backend/src/engine/ludo.js (START, SAFE, track length 52). */
object LudoBoard {
    val seatColors = listOf(Color(0xFFE53935), Color(0xFF43A047), Color(0xFFFDD835), Color(0xFF1E88E5))
    val START = intArrayOf(0, 13, 26, 39)
    val SAFE = setOf(0, 8, 13, 21, 26, 34, 39, 47)

    /** 52 shared squares as (column,row), clockwise, index 0 = red start. */
    val track: List<Pair<Int, Int>> = buildList {
        for (c in 1..5) add(c to 6)
        for (r in 5 downTo 0) add(6 to r)
        add(7 to 0)
        for (r in 0..5) add(8 to r)
        for (c in 9..14) add(c to 6)
        add(14 to 7)
        for (c in 14 downTo 9) add(c to 8)
        for (r in 9..14) add(8 to r)
        add(7 to 14)
        for (r in 14 downTo 9) add(6 to r)
        for (c in 5 downTo 0) add(c to 8)
        add(0 to 7)
        add(0 to 6)
    }

    /** Home lane squares (progress 51..55) per seat. */
    val lanes: List<List<Pair<Int, Int>>> = listOf(
        (1..5).map { it to 7 }, (1..5).map { 7 to it }, (13 downTo 9).map { it to 7 }, (13 downTo 9).map { 7 to it },
    )
    private val baseOrigin = listOf(0 to 0, 9 to 0, 9 to 9, 0 to 9)

    /** Token centre in cell units. progress: -1 base, 0..50 track, 51..55 lane, 56 home. */
    fun position(seat: Int, token: Int, p: Int): Offset = when {
        p == -1 -> { val (ox, oy) = baseOrigin[seat]; Offset(ox + 2f + 2f * (token % 2), oy + 2f + 2f * (token / 2)) }
        p <= 50 -> { val (c, r) = track[(START[seat] + p) % 52]; Offset(c + 0.5f, r + 0.5f) }
        p <= 55 -> { val (c, r) = lanes[seat][p - 51]; Offset(c + 0.5f, r + 0.5f) }
        else -> Offset(7.5f + (token % 2 - 0.5f) * 0.6f + dx(seat), 7.5f + (token / 2 - 0.5f) * 0.6f + dy(seat))
    }
    private fun dx(seat: Int) = when (seat) { 0 -> -0.9f; 2 -> 0.9f; else -> 0f }
    private fun dy(seat: Int) = when (seat) { 1 -> -0.9f; 3 -> 0.9f; else -> 0f }
}

@Composable
fun LudoBoardView(game: Game, myUserId: Long, onTokenTap: (Int) -> Unit, modifier: Modifier = Modifier) {
    val myTurn = game.status == "playing" && game.current?.userId == myUserId && game.dice != null
    val tappable = if (myTurn) game.legal else emptyList()
    // The board is a fixed geometry: never mirror it in RTL languages.
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Canvas(
            modifier.fillMaxWidth().aspectRatio(1f).pointerInput(game.version, myTurn) {
                detectTapGestures { tap ->
                    val cell = size.width / 15f
                    val me = game.current ?: return@detectTapGestures
                    tappable.minByOrNull { i -> (LudoBoard.position(me.seat, i, me.tokens[i]) * cell - tap).getDistance() }?.let { i ->
                        val d = (LudoBoard.position(me.seat, i, me.tokens[i]) * cell - tap).getDistance()
                        if (d < cell * 0.8f) onTokenTap(i)
                    }
                }
            },
        ) { drawBoard(game, tappable) }
    }
}

private fun DrawScope.drawBoard(game: Game, tappable: List<Int>) {
    val cell = size.width / 15f
    fun rect(c: Int, r: Int, color: Color) = drawRect(color, Offset(c * cell, r * cell), Size(cell, cell))
    fun outline(c: Int, r: Int) = drawRect(Color(0xFF9E9E9E), Offset(c * cell, r * cell), Size(cell, cell), style = Stroke(1f))

    drawRect(Color.White, size = size)
    // bases
    val origins = listOf(0 to 0, 9 to 0, 9 to 9, 0 to 9)
    origins.forEachIndexed { s, (ox, oy) ->
        drawRect(LudoBoard.seatColors[s], Offset(ox * cell, oy * cell), Size(6 * cell, 6 * cell))
        drawRect(Color.White, Offset((ox + 1) * cell, (oy + 1) * cell), Size(4 * cell, 4 * cell))
        for (t in 0..3) drawCircle(LudoBoard.seatColors[s].copy(alpha = 0.35f), cell * 0.45f, LudoBoard.position(s, t, -1) * cell)
    }
    // track
    LudoBoard.track.forEachIndexed { i, (c, r) ->
        val startSeat = LudoBoard.START.indexOf(i)
        rect(c, r, if (startSeat >= 0) LudoBoard.seatColors[startSeat].copy(alpha = 0.55f) else Color.White)
        outline(c, r)
        if (i in LudoBoard.SAFE && startSeat < 0) drawCircle(Color(0xFF757575), cell * 0.12f, Offset((c + 0.5f) * cell, (r + 0.5f) * cell))
    }
    // lanes
    LudoBoard.lanes.forEachIndexed { s, cells -> cells.forEach { (c, r) -> rect(c, r, LudoBoard.seatColors[s].copy(alpha = 0.6f)); outline(c, r) } }
    // centre: four triangles
    val cx = 7.5f * cell; val cy = 7.5f * cell
    val corners = listOf(Offset(6 * cell, 6 * cell), Offset(9 * cell, 6 * cell), Offset(9 * cell, 9 * cell), Offset(6 * cell, 9 * cell))
    val centreSeats = listOf(0 to (3 to 0), 1 to (0 to 1), 2 to (1 to 2), 3 to (2 to 3)) // seat -> corner pair
    centreSeats.forEach { (seat, pair) ->
        val a = corners[pair.first]; val b = corners[pair.second]
        drawPath(Path().apply { moveTo(a.x, a.y); lineTo(b.x, b.y); lineTo(cx, cy); close() }, LudoBoard.seatColors[seat])
    }

    // tokens: spread tokens that share a square so every one stays visible
    val seen = HashMap<Pair<Int, Int>, Int>()
    game.players.forEach { pl ->
        pl.tokens.forEachIndexed { i, p ->
            val base = LudoBoard.position(pl.seat, i, p)
            val key = (base.x * 10).toInt() to (base.y * 10).toInt()
            val n = seen.merge(key, 1, Int::plus)!! - 1
            val center = (base + Offset(n * 0.16f, -n * 0.16f)) * cell
            val isCurrent = game.current?.userId == pl.userId
            if (pl.left) return@forEachIndexed
            drawCircle(Color.Black.copy(alpha = 0.25f), cell * 0.40f, center + Offset(2f, 3f))
            drawCircle(LudoBoard.seatColors[pl.seat], cell * 0.36f, center)
            drawCircle(Color.White, cell * 0.36f, center, style = Stroke(cell * 0.07f))
            if (isCurrent && i in tappable) drawCircle(Color.Black, cell * 0.46f, center, style = Stroke(cell * 0.09f))
        }
    }
}
