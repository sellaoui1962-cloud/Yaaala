@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.seng.ludorooms.ui.rooms

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.seng.ludorooms.AppGraph
import com.seng.ludorooms.R
import com.seng.ludorooms.data.ApiException
import com.seng.ludorooms.data.Room
import com.seng.ludorooms.data.RoomSettings
import com.seng.ludorooms.ui.common.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class RoomsUi(
    val loading: Boolean = true, val error: String? = null, val rooms: List<Room> = emptyList(),
    val query: String = "", val actionError: String? = null, val busy: Boolean = false,
)

class RoomsViewModel(private val g: AppGraph) : ViewModel() {
    val ui = MutableStateFlow(RoomsUi())
    val activeRoom: StateFlow<Room?> = g.activeRoom
    private var job: Job? = null

    init { load() }

    fun load() { fetch(0) }

    fun onQuery(q: String) { ui.update { it.copy(query = q) }; fetch(350) }

    private fun fetch(debounceMs: Long) {
        job?.cancel()
        job = viewModelScope.launch {
            if (debounceMs > 0) delay(debounceMs)
            ui.update { it.copy(loading = true, error = null) }
            try {
                val rooms = g.api.rooms(ui.value.query.trim())
                ui.update { it.copy(loading = false, rooms = rooms) }
            } catch (e: ApiException) { ui.update { it.copy(loading = false, error = e.code) } }
        }
    }

    fun join(id: Long, onDone: (Long) -> Unit) = run({ g.api.joinRoom(id) }, onDone)

    fun create(name: String, isPrivate: Boolean, max: Int, s: RoomSettings, onDone: (Long) -> Unit) =
        run({ g.api.createRoom(name.trim(), isPrivate, max, s) }, onDone)

    private fun run(call: suspend () -> Room, onDone: (Long) -> Unit) {
        viewModelScope.launch {
            ui.update { it.copy(busy = true, actionError = null) }
            try {
                val room = call()
                g.setActiveRoom(room)
                ui.update { it.copy(busy = false) }
                onDone(room.id)
            } catch (e: ApiException) { ui.update { it.copy(busy = false, actionError = e.code) } }
        }
    }
}

@Composable
fun RoomsScreen(onOpenRoom: (Long) -> Unit) {
    val vm = graphViewModel { RoomsViewModel(it) }
    val ui by vm.ui.collectAsStateWithLifecycle()
    val active by vm.activeRoom.collectAsStateWithLifecycle()
    var showCreate by rememberSaveable { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = ui.query, onValueChange = vm::onQuery, singleLine = true, modifier = Modifier.weight(1f),
                placeholder = { Text(stringResource(R.string.search_rooms)) },
            )
            TextButton(onClick = { vm.load() }) { Text(stringResource(R.string.refresh)) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { showCreate = true }) { Text(stringResource(R.string.create_room)) }
        }
        active?.let { room ->
            Card(Modifier.fillMaxWidth().padding(12.dp), onClick = { onOpenRoom(room.id) }) {
                Text(stringResource(R.string.return_to_room, room.name), Modifier.padding(16.dp), style = MaterialTheme.typography.titleSmall)
            }
        }
        InlineError(ui.actionError, Modifier.padding(horizontal = 16.dp))

        when {
            ui.loading && ui.rooms.isEmpty() -> LoadingBox()
            ui.error != null -> ErrorBox(ui.error!!, onRetry = { vm.load() })
            ui.rooms.isEmpty() -> EmptyBox(stringResource(R.string.no_rooms))
            else -> LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(ui.rooms, key = { it.id }) { r ->
                    val full = r.memberCount >= r.maxPlayers
                    val playing = r.gameStatus == "playing"
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(r.name, style = MaterialTheme.typography.titleMedium)
                                    Text(stringResource(R.string.room_summary, r.memberCount, r.maxPlayers, r.ownerName),
                                        style = MaterialTheme.typography.bodySmall)
                                    Text(
                                        stringResource(when (r.gameStatus) {
                                            "playing" -> R.string.status_playing
                                            "finished" -> R.string.status_finished
                                            else -> R.string.status_lobby
                                        }),
                                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary,
                                    )
                                }
                                Button(onClick = { vm.join(r.id, onOpenRoom) }, enabled = !full && !playing && !ui.busy) {
                                    Text(stringResource(R.string.join))
                                }
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(r.members.joinToString(" · ") { it.displayName }, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }

    if (showCreate) CreateRoomDialog(
        busy = ui.busy,
        onDismiss = { showCreate = false },
        onCreate = { name, priv, max, s -> vm.create(name, priv, max, s) { showCreate = false; onOpenRoom(it) } },
    )
}

@Composable
private fun CreateRoomDialog(busy: Boolean, onDismiss: () -> Unit, onCreate: (String, Boolean, Int, RoomSettings) -> Unit) {
    var name by rememberSaveable { mutableStateOf("") }
    var priv by rememberSaveable { mutableStateOf(false) }
    var max by rememberSaveable { mutableIntStateOf(4) }
    var six by rememberSaveable { mutableStateOf(true) }
    var cap by rememberSaveable { mutableStateOf(false) }
    var safe by rememberSaveable { mutableStateOf(true) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.create_room)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(name, { name = it.take(40) }, singleLine = true, label = { Text(stringResource(R.string.room_name)) })
                Text(stringResource(R.string.max_players, max))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(2, 3, 4).forEach { n -> FilterChip(selected = max == n, onClick = { max = n }, label = { Text("$n") }) }
                }
                SwitchRow(stringResource(R.string.private_room), priv) { priv = it }
                SwitchRow(stringResource(R.string.extra_turn_six), six) { six = it }
                SwitchRow(stringResource(R.string.extra_turn_capture), cap) { cap = it }
                SwitchRow(stringResource(R.string.safe_squares), safe) { safe = it }
            }
        },
        confirmButton = {
            Button(onClick = { onCreate(name, priv, max, RoomSettings(six, cap, safe)) }, enabled = name.isNotBlank() && !busy) {
                Text(stringResource(R.string.create))
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

@Composable
fun SwitchRow(label: String, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}
