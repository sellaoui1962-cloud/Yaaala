@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.seng.ludorooms.ui.common

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.seng.ludorooms.R
import com.seng.ludorooms.data.ChatMessage

/** Newest message at the bottom; reverseLayout keeps the list pinned there without manual scrolling. */
@Composable
fun MessageList(
    messages: List<ChatMessage>, myId: Long, showSender: Boolean, modifier: Modifier = Modifier,
    canLoadOlder: Boolean = false, onLoadOlder: () -> Unit = {},
) {
    if (messages.isEmpty()) { EmptyBox(stringResource(R.string.no_messages), modifier); return }
    LazyColumn(modifier, reverseLayout = true, contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        items(messages.asReversed(), key = { it.id }) { m ->
            val mine = m.senderId == myId
            Column(Modifier.fillMaxWidth(), horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = if (mine) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                ) {
                    Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                        if (showSender && !mine) Text(m.senderName, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        Text(m.text)
                    }
                }
            }
        }
        if (canLoadOlder) item { TextButton(onClick = onLoadOlder, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.load_older)) } }
    }
}

@Composable
fun MessageInput(onSend: (String) -> Unit, modifier: Modifier = Modifier) {
    var text by rememberSaveable { mutableStateOf("") }
    fun submit() { val t = text.trim(); if (t.isNotEmpty()) { onSend(t); text = "" } }
    Row(modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value = text, onValueChange = { if (it.length <= 500) text = it },
            modifier = Modifier.weight(1f), singleLine = true,
            placeholder = { Text(stringResource(R.string.type_message)) },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { submit() }),
        )
        IconButton(onClick = { submit() }, enabled = text.isNotBlank()) {
            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = stringResource(R.string.send))
        }
    }
}
