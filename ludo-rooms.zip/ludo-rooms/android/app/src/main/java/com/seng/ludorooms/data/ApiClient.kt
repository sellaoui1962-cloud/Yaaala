package com.seng.ludorooms.data

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/** code = backend error code ("network" for transport failures). */
class ApiException(val code: String, val status: Int = 0, msg: String? = null) : Exception(msg ?: code)

class ApiClient(private val session: SessionStore) {
    val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val http = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS).readTimeout(15, TimeUnit.SECONDS).build()
    private val refreshMutex = Mutex()
    private val jsonType = "application/json; charset=utf-8".toMediaType()

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private suspend fun raw(
        method: String, path: String, body: JsonObject? = null, auth: Boolean = true, retry: Boolean = true,
    ): String = withContext(Dispatchers.IO) {
        val rb = if (method == "GET" || method == "DELETE") null
        else (body ?: JsonObject(emptyMap())).toString().toRequestBody(jsonType)
        val req = Request.Builder().url(session.serverUrl + path).method(method, rb).apply {
            if (auth) session.accessToken?.let { header("Authorization", "Bearer $it") }
        }.build()
        val (status, text) = try {
            http.newCall(req).execute().use { it.code to it.body?.string().orEmpty() }
        } catch (e: IOException) {
            throw ApiException("network", 0, e.message)
        } catch (e: IllegalArgumentException) { // malformed server URL
            throw ApiException("network", 0, e.message)
        }
        if (status in 200..299) return@withContext text
        if (status == 401 && auth && retry && session.refreshToken != null && refresh()) {
            return@withContext raw(method, path, body, auth, false)
        }
        val err = runCatching { json.decodeFromString<ErrorBody>(text) }.getOrNull()
        throw ApiException(err?.error?.ifEmpty { null } ?: "http_$status", status, err?.message)
    }

    private fun tokenExpSeconds(token: String?): Long {
        if (token == null) return 0
        return try {
            val payload = token.substringBefore('.')
            val bytes = Base64.decode(payload, Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)
            json.parseToJsonElement(String(bytes)).jsonObject["exp"]?.jsonPrimitive?.content?.toLong() ?: 0
        } catch (e: Exception) { 0 }
    }

    /** Refreshes tokens; false if the session is no longer valid (user is signed out) or network failed. */
    suspend fun refresh(): Boolean = refreshMutex.withLock {
        if (tokenExpSeconds(session.accessToken) > System.currentTimeMillis() / 1000 + 30) return true
        val rt = session.refreshToken ?: return false
        try {
            val text = raw("POST", "/api/auth/refresh", buildJsonObject { put("refreshToken", rt) }, auth = false, retry = false)
            session.updateTokens(json.decodeFromString<AuthResponse>(text))
            true
        } catch (e: ApiException) {
            if (e.status == 401) session.clear()
            false
        }
    }

    /** A token valid for at least 60 s, or null when signed out. */
    suspend fun validAccessToken(): String? {
        if (session.refreshToken == null) return null
        if (tokenExpSeconds(session.accessToken) <= System.currentTimeMillis() / 1000 + 60) refresh()
        return session.accessToken
    }

    private suspend inline fun <reified T> get(path: String): T = json.decodeFromString(raw("GET", path))
    private suspend inline fun <reified T> post(path: String, body: JsonObject = JsonObject(emptyMap())): T =
        json.decodeFromString(raw("POST", path, body))

    // ----- auth -----
    suspend fun register(username: String, password: String, displayName: String): AuthResponse =
        json.decodeFromString(raw("POST", "/api/auth/register", buildJsonObject {
            put("username", username); put("password", password); put("displayName", displayName)
        }, auth = false))

    suspend fun login(username: String, password: String): AuthResponse =
        json.decodeFromString(raw("POST", "/api/auth/login", buildJsonObject {
            put("username", username); put("password", password)
        }, auth = false))

    suspend fun logout() {
        val rt = session.refreshToken ?: return
        try { raw("POST", "/api/auth/logout", buildJsonObject { put("refreshToken", rt) }, auth = false) } catch (_: ApiException) { }
    }

    suspend fun me(): MeResponse = get("/api/me")

    // ----- friends -----
    suspend fun friends(): FriendsResponse = get("/api/friends")
    suspend fun searchUsers(q: String): List<SearchUser> = get<SearchResponse>("/api/users/search?q=${enc(q)}").users
    suspend fun requestFriend(username: String) { raw("POST", "/api/friends/request", buildJsonObject { put("username", username) }) }
    suspend fun acceptFriend(userId: Long) { raw("POST", "/api/friends/accept", buildJsonObject { put("userId", userId) }) }
    suspend fun declineFriend(userId: Long) { raw("POST", "/api/friends/decline", buildJsonObject { put("userId", userId) }) }
    suspend fun removeFriend(userId: Long) { raw("DELETE", "/api/friends/$userId") }

    // ----- rooms -----
    suspend fun rooms(q: String): List<Room> = get<RoomsResponse>("/api/rooms?q=${enc(q)}").rooms
    suspend fun room(id: Long): Room = get<RoomResponse>("/api/rooms/$id").room
    suspend fun joinRoom(id: Long): Room = post<RoomResponse>("/api/rooms/$id/join").room
    suspend fun leaveRoom() { raw("POST", "/api/rooms/leave") }

    suspend fun createRoom(name: String, isPrivate: Boolean, maxPlayers: Int, s: RoomSettings): Room =
        post<RoomResponse>("/api/rooms", buildJsonObject {
            put("name", name); put("isPrivate", isPrivate); put("maxPlayers", maxPlayers)
            put("settings", buildJsonObject {
                put("extraTurnOnSix", s.extraTurnOnSix); put("extraTurnOnCapture", s.extraTurnOnCapture); put("safeSquares", s.safeSquares)
            })
        }).room

    suspend fun updateSettings(roomId: Long, s: RoomSettings): Room =
        json.decodeFromString<RoomResponse>(raw("PATCH", "/api/rooms/$roomId", buildJsonObject {
            put("settings", buildJsonObject {
                put("extraTurnOnSix", s.extraTurnOnSix); put("extraTurnOnCapture", s.extraTurnOnCapture); put("safeSquares", s.safeSquares)
            })
        })).room

    suspend fun roomMessages(roomId: Long, before: Long? = null): List<ChatMessage> =
        get<MessagesResponse>("/api/rooms/$roomId/messages" + (before?.let { "?before=$it" } ?: "")).messages

    suspend fun voiceToken(roomId: Long): VoiceToken = post("/api/rooms/$roomId/voice-token")

    // ----- direct messages -----
    suspend fun dmHistory(userId: Long, before: Long? = null): List<ChatMessage> =
        get<MessagesResponse>("/api/dm/$userId" + (before?.let { "?before=$it" } ?: "")).messages

    suspend fun sendDm(userId: Long, text: String): ChatMessage =
        post<MessageResponse>("/api/dm/$userId", buildJsonObject { put("text", text) }).message
}
