package com.seng.ludorooms.data

import kotlinx.serialization.Serializable

@Serializable data class User(val id: Long, val username: String, val displayName: String)

@Serializable data class AuthResponse(
    val accessToken: String, val refreshToken: String, val expiresIn: Int, val user: User,
)

@Serializable data class Member(
    val id: Long, val username: String, val displayName: String, val online: Boolean,
    val inVoice: Boolean = false, val muted: Boolean = false, val seat: Int? = null,
)

@Serializable data class RoomSettings(
    val extraTurnOnSix: Boolean = true, val extraTurnOnCapture: Boolean = false, val safeSquares: Boolean = true,
)

@Serializable data class Room(
    val id: Long, val name: String, val ownerId: Long, val ownerName: String = "",
    val isPrivate: Boolean = false, val maxPlayers: Int = 4, val settings: RoomSettings = RoomSettings(),
    val memberCount: Int = 0, val onlineCount: Int = 0, val gameStatus: String = "lobby",
    val members: List<Member> = emptyList(),
)

@Serializable data class Friend(
    val id: Long, val username: String, val displayName: String, val online: Boolean = false,
    val roomId: Long? = null, val roomName: String? = null, val canJoin: Boolean = false,
)

@Serializable data class FriendsResponse(
    val friends: List<Friend> = emptyList(), val incoming: List<User> = emptyList(), val outgoing: List<User> = emptyList(),
)

@Serializable data class SearchUser(val id: Long, val username: String, val displayName: String, val relation: String)
@Serializable data class SearchResponse(val users: List<SearchUser> = emptyList())

@Serializable data class ChatMessage(
    val id: Long, val roomId: Long? = null, val senderId: Long, val senderName: String = "",
    val recipientId: Long? = null, val text: String, val createdAt: Long = 0,
)

@Serializable data class GamePlayer(
    val seat: Int, val userId: Long, val name: String, val tokens: List<Int>, val left: Boolean = false,
)

@Serializable data class GameEvent(
    val type: String = "", val userId: Long? = null, val dice: Int? = null, val captured: Int? = null,
)

@Serializable data class Game(
    val status: String, val version: Int = 0, val players: List<GamePlayer> = emptyList(), val turn: Int = 0,
    val dice: Int? = null, val finished: List<Long> = emptyList(), val event: GameEvent? = null,
    val legal: List<Int> = emptyList(),
) {
    val current: GamePlayer? get() = players.getOrNull(turn)
}

@Serializable data class VoiceToken(val appId: String, val channel: String, val uid: Long, val token: String, val expiresIn: Int = 3600)

@Serializable data class MeResponse(val user: User, val roomId: Long? = null)
@Serializable data class RoomResponse(val room: Room)
@Serializable data class RoomsResponse(val rooms: List<Room> = emptyList())
@Serializable data class MessagesResponse(val messages: List<ChatMessage> = emptyList())
@Serializable data class MessageResponse(val message: ChatMessage)
@Serializable data class ErrorBody(val error: String = "", val message: String? = null)
