@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.seng.ludorooms.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import com.seng.ludorooms.R
import com.seng.ludorooms.ui.friends.FriendsScreen
import com.seng.ludorooms.ui.rooms.RoomsScreen
import com.seng.ludorooms.ui.settings.SettingsScreen

@Composable
fun HomeScreen(onOpenRoom: (Long) -> Unit, onOpenDm: (Long, String) -> Unit) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val items = listOf(
        Triple(R.string.nav_friends, Icons.Default.Person, 0),
        Triple(R.string.nav_rooms, Icons.Default.Home, 1),
        Triple(R.string.nav_settings, Icons.Default.Settings, 2),
    )
    Scaffold(bottomBar = {
        NavigationBar {
            items.forEach { (label, icon, i) ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i },
                    icon = { Icon(icon, contentDescription = null) }, label = { Text(stringResource(label)) })
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) {
                0 -> FriendsScreen(onOpenRoom, onOpenDm)
                1 -> RoomsScreen(onOpenRoom)
                else -> SettingsScreen()
            }
        }
    }
}
