@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.seng.ludorooms.ui.settings

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.os.LocaleListCompat
import com.seng.ludorooms.App
import com.seng.ludorooms.R
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen() {
    val graph = (LocalContext.current.applicationContext as App).graph
    val scope = rememberCoroutineScope()
    var lang by remember {
        mutableStateOf(AppCompatDelegate.getApplicationLocales().toLanguageTags().substringBefore('-'))
    }
    fun setLang(tag: String) {
        lang = tag
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag)) // empty tag = system default
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(stringResource(R.string.signed_in_as, graph.session.displayName), style = MaterialTheme.typography.titleMedium)
        Text(graph.session.serverUrl, style = MaterialTheme.typography.bodySmall)
        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        Text(stringResource(R.string.language), style = MaterialTheme.typography.titleSmall)
        listOf("" to R.string.lang_system, "en" to R.string.lang_en, "ar" to R.string.lang_ar).forEach { (tag, label) ->
            Row(Modifier.fillMaxWidth()) {
                RadioButton(selected = lang == tag, onClick = { setLang(tag) })
                Text(stringResource(label), Modifier.padding(top = 12.dp))
            }
        }
        Spacer(Modifier.weight(1f))
        Button(onClick = { scope.launch { graph.signOut() } }, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.logout))
        }
    }
}
