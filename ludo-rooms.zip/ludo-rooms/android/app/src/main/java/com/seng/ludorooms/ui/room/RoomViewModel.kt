@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.seng.ludorooms.ui.room

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.seng.ludorooms.AppGraph
import com.seng.ludorooms.data.*
import com.seng.ludorooms.voice.VoiceStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

class RoomViewModel(private val g: AppGraph, val roomId: Long) : ViewModel() {
    val room: StateFlow<Room?> = g.activeRoom
    val game: StateFlow<Game?> = g.game
    val voiceStatus: StateFlow<VoiceStatus> = g.voice.status
    val voiceMuted: StateFlow<Boolean> = g.voice.muted
    val speaking: StateFlow<Set<Int>> = g.voice.speaking
    val connected: StateFlow<Boolean> = g.realtime.connected
    val myId: Long get() = g.session.userId

    val messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatLoading = MutableStateFlow(true)
    val hasMore = MutableStateFlow(false)
    val error = MutableStateFlow<String?>(null)

    private fun merge(add: List<ChatMessage>) = messages.update { cur -> (cur + add).distinctBy { it.id }.sortedBy { it.id } }

    init {
        loadHistory()
        viewModelScope.launch {
            g.realtime.events.collect { ev ->
                when (ev) {
                    is RtEvent.Chat -> if (ev.message.roomId == roomId) merge(listOf(ev.message))
                    is RtEvent.Error -> error.value = ev.code
                    else -> Unit
                }
            }
        }
    }

    fun loadHistory() {
        viewModelScope.launch {
            chatLoading.value = true
            try { val h = g.api.roomMessages(roomId); merge(h); hasMore.value = h.size >= 50 }
            catch (e: ApiException) { if (e.code != "not_member") error.value = e.code }
            chatLoading.value = false
        }
    }

    fun loadOlder() {
        val first = messages.value.firstOrNull() ?: return
        viewModelScope.launch {
            try { val h = g.api.roomMessages(roomId, first.id); merge(h); hasMore.value = h.size >= 50 }
            catch (e: ApiException) { error.value = e.code }
        }
    }

    fun clearError() { error.value = null }

    private fun sendWs(type: String, extra: (kotlinx.serialization.json.JsonObjectBuilder.() -> Unit)? = null) {
        val ok = g.realtime.send(buildJsonObject { put("t", type); extra?.invoke(this) })
        if (!ok) error.value = "network"
    }

    // ----- game -----
    fun startGame() = sendWs("game.start")
    fun roll() = sendWs("game.roll")
    fun move(token: Int) = sendWs("game.move") { put("token", token) }

    fun updateSettings(s: RoomSettings) {
        viewModelScope.launch {
            try { g.setActiveRoom(g.api.updateSettings(roomId, s)) } catch (e: ApiException) { error.value = e.code }
        }
    }

    // ----- chat -----
    fun sendChat(text: String) = sendWs("chat.send") { put("text", text) }

    // ----- room -----
    fun leaveRoom() {
        viewModelScope.launch {
            g.voice.leave()
            try { g.api.leaveRoom() } catch (e: ApiException) { error.value = e.code }
            g.activeRoom.value = null; g.game.value = null
        }
    }

    // ----- voice -----
    fun joinVoice() {
        viewModelScope.launch {
            try {
                val t = g.api.voiceToken(roomId)
                g.voice.onTokenWillExpire = {
                    viewModelScope.launch { runCatching { g.voice.renewToken(g.api.voiceToken(roomId).token) } }
                }
                g.voice.join(t.appId, t.token, t.channel, t.uid.toInt())
                g.sendVoiceState(inVoice = true, muted = true)
            } catch (e: ApiException) { error.value = e.code }
        }
    }

    fun toggleMute() {
        val m = !g.voice.muted.value
        g.voice.setMuted(m)
        g.sendVoiceState(inVoice = true, muted = m)
    }

    fun leaveVoice() {
        g.voice.leave()
        g.sendVoiceState(inVoice = false, muted = true)
    }
}
