package com.seng.ludorooms

import android.content.Context
import com.seng.ludorooms.data.ApiClient
import com.seng.ludorooms.data.Game
import com.seng.ludorooms.data.RealtimeClient
import com.seng.ludorooms.data.Room
import com.seng.ludorooms.data.RtEvent
import com.seng.ludorooms.data.SessionStore
import com.seng.ludorooms.voice.VoiceEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

/** Process-wide singletons + the single source of truth for "which room am I in / what is its game". */
class AppGraph(ctx: Context) {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    val session = SessionStore(ctx)
    val api = ApiClient(session)
    val realtime = RealtimeClient(session, api, scope)
    val voice = VoiceEngine(ctx.applicationContext)

    val activeRoom = MutableStateFlow<Room?>(null)
    val game = MutableStateFlow<Game?>(null)
    val presence = MutableSharedFlow<RtEvent.Presence>(extraBufferCapacity = 64)

    init {
        scope.launch { realtime.events.collect { onEvent(it) } }
        scope.launch {
            session.loggedIn.collect { signedIn ->
                if (signedIn) {
                    realtime.start()
                    runCatching { api.me().roomId?.let { activeRoom.value = api.room(it) } }
                } else {
                    realtime.stop(); voice.leave(); activeRoom.value = null; game.value = null
                }
            }
        }
    }

    private fun onEvent(ev: RtEvent) {
        when (ev) {
            is RtEvent.RoomState -> {
                if (activeRoom.value?.id != ev.room.id) game.value = null
                activeRoom.value = ev.room
            }
            is RtEvent.GameState -> if (activeRoom.value?.id == ev.roomId) game.value = ev.game
            is RtEvent.RoomLeft -> { voice.leave(); activeRoom.value = null; game.value = null }
            is RtEvent.Presence -> presence.tryEmit(ev)
            else -> Unit
        }
    }

    fun setActiveRoom(room: Room) { if (activeRoom.value?.id != room.id) game.value = null; activeRoom.value = room }

    fun sendVoiceState(inVoice: Boolean, muted: Boolean) {
        realtime.send(buildJsonObject { put("t", "voice.state"); put("inVoice", inVoice); put("muted", muted) })
    }

    suspend fun signOut() {
        runCatching { api.logout() }
        session.clear()
    }
}
