package com.seng.ludorooms.data

import android.content.Context
import com.seng.ludorooms.BuildConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Persists the session. Plain private SharedPreferences (allowBackup=false); for production
 * consider EncryptedSharedPreferences / Keystore-backed storage.
 */
class SessionStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("session", Context.MODE_PRIVATE)
    private val _loggedIn = MutableStateFlow(sp.getString("refresh", null) != null)
    val loggedIn: StateFlow<Boolean> = _loggedIn

    var serverUrl: String
        get() = sp.getString("server", null) ?: BuildConfig.DEFAULT_SERVER_URL
        set(v) { sp.edit().putString("server", v.trim().trimEnd('/')).apply() }

    val accessToken: String? get() = sp.getString("access", null)
    val refreshToken: String? get() = sp.getString("refresh", null)
    val userId: Long get() = sp.getLong("uid", 0L)
    val displayName: String get() = sp.getString("name", "") ?: ""

    fun save(a: AuthResponse) {
        sp.edit().putString("access", a.accessToken).putString("refresh", a.refreshToken)
            .putLong("uid", a.user.id).putString("name", a.user.displayName).apply()
        _loggedIn.value = true
    }

    fun updateTokens(a: AuthResponse) = save(a)

    fun clear() {
        sp.edit().remove("access").remove("refresh").remove("uid").remove("name").apply()
        _loggedIn.value = false
    }
}
