package com.seng.ludorooms.ui.friends

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.seng.ludorooms.AppGraph
import com.seng.ludorooms.R
import com.seng.ludorooms.data.*
import com.seng.ludorooms.ui.common.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class FriendsUi(
    val loading: Boolean = true, val error: String? = null,
    val friends: List<Friend> = emptyList(), val incoming: List<User> = emptyList(), val outgoing: List<User> = emptyList(),
    val query: String = "", val results: List<SearchUser>? = null, val searching: Boolean = false,
    val actionError: String? = null,
)

class FriendsViewModel(private val g: AppGraph) : ViewModel() {
    val ui = MutableStateFlow(FriendsUi())
    private var searchJob: Job? = null

    init {
        load()
        // Presence arrives over the socket, so no polling is needed.
        viewModelScope.launch {
            g.presence.collect { p ->
                ui.update { s -> s.copy(friends = s.friends.map { if (it.id == p.userId) it.copy(online = p.online) else it }) }
            }
        }
        viewModelScope.launch { g.realtime.events.collect { if (it is RtEvent.FriendsChanged) load(silent = true) } }
        // Friends' room activity changes: refresh when our own connection (re)opens.
        viewModelScope.launch { g.realtime.connected.collect { if (it) load(silent = true) } }
    }

    fun load(silent: Boolean = false) {
        viewModelScope.launch {
            if (!silent) ui.update { it.copy(loading = true, error = null) }
            try {
                val r = g.api.friends()
                ui.update { it.copy(loading = false, error = null, friends = r.friends, incoming = r.incoming, outgoing = r.outgoing) }
            } catch (e: ApiException) {
                if (!silent) ui.update { it.copy(loading = false, error = e.code) }
            }
        }
    }

    fun onQuery(q: String) {
        ui.update { it.copy(query = q) }
        searchJob?.cancel()
        if (q.trim().length < 2) { ui.update { it.copy(results = null, searching = false) }; return }
        searchJob = viewModelScope.launch {
            delay(350) // debounce keystrokes: fewer requests
            ui.update { it.copy(searching = true) }
            try {
                val r = g.api.searchUsers(q.trim())
                ui.update { it.copy(results = r, searching = false) }
            } catch (e: ApiException) {
                ui.update { it.copy(searching = false, actionError = e.code) }
            }
        }
    }

    private fun act(block: suspend () -> Unit) {
        viewModelScope.launch {
            ui.update { it.copy(actionError = null) }
            try { block(); load(silent = true); onQuery(ui.value.query) }
            catch (e: ApiException) { ui.update { it.copy(actionError = e.code) } }
        }
    }

    fun add(username: String) = act { g.api.requestFriend(username) }
    fun accept(id: Long) = act { g.api.acceptFriend(id) }
    fun decline(id: Long) = act { g.api.declineFriend(id) }
    fun remove(id: Long) = act { g.api.removeFriend(id) }

    fun openRoom(roomId: Long, onJoined: (Long) -> Unit) {
        viewModelScope.launch {
            ui.update { it.copy(actionError = null) }
            try {
                val room = g.api.joinRoom(roomId)
                g.setActiveRoom(room)
                onJoined(room.id)
            } catch (e: ApiException) { ui.update { it.copy(actionError = e.code) } }
        }
    }
}

@Composable
fun FriendsScreen(onOpenRoom: (Long) -> Unit, onOpenDm: (Long, String) -> Unit) {
    val vm = graphViewModel { FriendsViewModel(it) }
    val ui by vm.ui.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = ui.query, onValueChange = vm::onQuery, singleLine = true, modifier = Modifier.weight(1f),
                placeholder = { Text(stringResource(R.string.search_users)) },
            )
            TextButton(onClick = { vm.load() }) { Text(stringResource(R.string.refresh)) }
        }
        InlineError(ui.actionError, Modifier.padding(horizontal = 16.dp))

        val results = ui.results
        when {
            ui.loading -> LoadingBox()
            ui.error != null -> ErrorBox(ui.error!!, onRetry = { vm.load() })
            results != null -> LazyColumn(contentPadding = PaddingValues(horizontal = 12.dp)) {
                if (results.isEmpty()) item { EmptyBox(stringResource(R.string.no_results)) }
                items(results, key = { it.id }) { u ->
                    ListItem(
                        leadingContent = { Avatar(u.displayName) },
                        headlineContent = { Text(u.displayName) },
                        supportingContent = { Text("@${u.username}") },
                        trailingContent = {
                            when (u.relation) {
                                "none" -> Button(onClick = { vm.add(u.username) }) { Text(stringResource(R.string.add_friend)) }
                                "pending_out" -> Text(stringResource(R.string.requested))
                                "pending_in" -> Button(onClick = { vm.accept(u.id) }) { Text(stringResource(R.string.accept)) }
                                else -> Text(stringResource(R.string.already_friends))
                            }
                        },
                    )
                }
            }
            else -> LazyColumn(contentPadding = PaddingValues(horizontal = 12.dp)) {
                if (ui.incoming.isNotEmpty()) {
                    item { Text(stringResource(R.string.friend_requests), style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(8.dp)) }
                    items(ui.incoming, key = { "in${it.id}" }) { u ->
                        ListItem(
                            leadingContent = { Avatar(u.displayName) },
                            headlineContent = { Text(u.displayName) },
                            supportingContent = { Text("@${u.username}") },
                            trailingContent = {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Button(onClick = { vm.accept(u.id) }) { Text(stringResource(R.string.accept)) }
                                    OutlinedButton(onClick = { vm.decline(u.id) }) { Text(stringResource(R.string.decline)) }
                                }
                            },
                        )
                    }
                }
                if (ui.friends.isEmpty() && ui.incoming.isEmpty()) item { EmptyBox(stringResource(R.string.no_friends)) }
                items(ui.friends, key = { "f${it.id}" }) { f ->
                    ListItem(
                        leadingContent = { Avatar(f.displayName, online = f.online) },
                        headlineContent = { Text(f.displayName) },
                        supportingContent = {
                            Column {
                                Text(stringResource(if (f.online) R.string.online else R.string.offline))
                                if (f.roomName != null) Text(stringResource(R.string.in_room, f.roomName), color = MaterialTheme.colorScheme.primary)
                            }
                        },
                        trailingContent = {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                if (f.roomId != null && f.canJoin) {
                                    Button(onClick = { vm.openRoom(f.roomId, onOpenRoom) }) { Text(stringResource(R.string.open_room)) }
                                }
                                OutlinedButton(onClick = { onOpenDm(f.id, f.displayName) }) { Text(stringResource(R.string.message)) }
                            }
                        },
                    )
                    HorizontalDivider()
                }
                if (ui.outgoing.isNotEmpty()) {
                    item { Text(stringResource(R.string.sent_requests), style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(8.dp)) }
                    items(ui.outgoing, key = { "out${it.id}" }) { u ->
                        ListItem(headlineContent = { Text(u.displayName) }, supportingContent = { Text("@${u.username}") })
                    }
                }
            }
        }
    }
}
