package com.seng.ludorooms.voice

import android.content.Context
import io.agora.rtc2.ChannelMediaOptions
import io.agora.rtc2.Constants
import io.agora.rtc2.IRtcEngineEventHandler
import io.agora.rtc2.RtcEngine
import io.agora.rtc2.RtcEngineConfig
import kotlinx.coroutines.flow.MutableStateFlow

enum class VoiceStatus { Idle, Connecting, Connected, Error }

/**
 * Thin wrapper over the Agora voice SDK. Needs an App ID + a token minted by OUR backend
 * (the Agora App Certificate never ships in the app).
 */
class VoiceEngine(private val appCtx: Context) {
    val status = MutableStateFlow(VoiceStatus.Idle)
    val muted = MutableStateFlow(true)
    /** Agora uids (== our user ids) currently producing audio. */
    val speaking = MutableStateFlow<Set<Int>>(emptySet())
    var onTokenWillExpire: (() -> Unit)? = null

    private var engine: RtcEngine? = null
    private var selfUid = 0

    private val handler = object : IRtcEngineEventHandler() {
        override fun onJoinChannelSuccess(channel: String?, uid: Int, elapsed: Int) { status.value = VoiceStatus.Connected }
        override fun onConnectionStateChanged(state: Int, reason: Int) {
            if (state == Constants.CONNECTION_STATE_FAILED) status.value = VoiceStatus.Error
        }
        override fun onAudioVolumeIndication(speakers: Array<IRtcEngineEventHandler.AudioVolumeInfo>?, totalVolume: Int) {
            speaking.value = speakers.orEmpty().filter { it.volume > 20 }.map { if (it.uid == 0) selfUid else it.uid }.toSet()
        }
        override fun onTokenPrivilegeWillExpire(token: String?) { onTokenWillExpire?.invoke() }
    }

    fun join(appId: String, token: String, channel: String, uid: Int) {
        leave()
        status.value = VoiceStatus.Connecting
        selfUid = uid
        try {
            val cfg = RtcEngineConfig().apply { mContext = appCtx; mAppId = appId; mEventHandler = handler }
            val e = RtcEngine.create(cfg)
            engine = e
            e.setChannelProfile(Constants.CHANNEL_PROFILE_COMMUNICATION)
            e.enableAudio()
            e.enableAudioVolumeIndication(500, 3, false)
            val opts = ChannelMediaOptions().apply {
                clientRoleType = Constants.CLIENT_ROLE_BROADCASTER
                autoSubscribeAudio = true
                publishMicrophoneTrack = true
                channelProfile = Constants.CHANNEL_PROFILE_COMMUNICATION
            }
            val rc = e.joinChannel(token, channel, uid, opts)
            if (rc != 0) throw IllegalStateException("joinChannel rc=$rc")
            e.muteLocalAudioStream(true) // always join muted; the user opts in to speaking
            muted.value = true
        } catch (t: Throwable) {
            status.value = VoiceStatus.Error
            destroy()
        }
    }

    fun setMuted(m: Boolean) { engine?.muteLocalAudioStream(m); muted.value = m }
    fun renewToken(token: String) { engine?.renewToken(token) }

    fun leave() {
        engine?.leaveChannel()
        destroy()
        status.value = VoiceStatus.Idle
        speaking.value = emptySet()
        muted.value = true
    }

    private fun destroy() {
        if (engine != null) { RtcEngine.destroy(); engine = null }
    }
}
