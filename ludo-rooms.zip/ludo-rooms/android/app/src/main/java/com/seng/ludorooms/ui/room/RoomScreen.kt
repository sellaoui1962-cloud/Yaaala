package com.seng.ludorooms.ui.room

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.seng.ludorooms.R
import com.seng.ludorooms.data.*
import com.seng.ludorooms.ui.common.*
import com.seng.ludorooms.ui.rooms.SwitchRow
import com.seng.ludorooms.voice.VoiceStatus

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoomScreen(roomId: Long, onBack: () -> Unit) {
    val vm = graphViewModel(key = "room$roomId") { RoomViewModel(it, roomId) }
    val room by vm.room.collectAsStateWithLifecycle()
    val game by vm.game.collectAsStateWithLifecycle()
    val connected by vm.connected.collectAsStateWithLifecycle()
    val error by vm.error.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var seenRoom by remember { mutableStateOf(false) }
    val snackbar = remember { SnackbarHostState() }

    if (room?.id == roomId) seenRoom = true
    // Left the room (or it closed): return to the lobby.
    LaunchedEffect(room?.id) { if (seenRoom && room?.id != roomId) onBack() }
    val errText = error?.let { errorMessage(it) }
    LaunchedEffect(errText) { if (errText != null) { snackbar.showSnackbar(errText); vm.clearError() } }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text(room?.name ?: "") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) } },
                actions = { TextButton(onClick = { vm.leaveRoom() }) { Text(stringResource(R.string.leave_room)) } },
            )
        },
    ) { pad ->
        val r = room
        if (r == null || r.id != roomId) { LoadingBox(Modifier.padding(pad)); return@Scaffold }
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (!connected) LinearProgressIndicator(Modifier.fillMaxWidth()) // reconnecting
            MembersRow(r)
            TabRow(selectedTabIndex = tab) {
                listOf(R.string.tab_game, R.string.tab_chat, R.string.tab_voice).forEachIndexed { i, label ->
                    Tab(selected = tab == i, onClick = { tab = i }, text = { Text(stringResource(label)) })
                }
            }
            when (tab) {
                0 -> GameTab(r, game, vm)
                1 -> ChatTab(vm)
                else -> VoiceTab(r, vm)
            }
        }
    }
}

@Composable
private fun MembersRow(room: Room) {
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        room.members.forEach { m ->
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Avatar(m.displayName, online = m.online)
                Text(m.displayName + if (m.inVoice) (if (m.muted) " 🔇" else " 🎙") else "", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

// ------------------------------------------------------------------ game
@Composable
private fun GameTab(room: Room, game: Game?, vm: RoomViewModel) {
    val myId = vm.myId
    val isOwner = room.ownerId == myId
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (game != null && game.status == "playing") PlayingPanel(game, myId, vm)
        else {
            if (game != null && game.status == "finished") {
                Text(stringResource(R.string.ranking), style = MaterialTheme.typography.titleMedium)
                game.finished.forEachIndexed { i, uid ->
                    val p = game.players.firstOrNull { it.userId == uid }
                    Text(stringResource(R.string.rank_line, i + 1, p?.name ?: "?"))
                }
            }
            SettingsPanel(room, isOwner, vm)
            if (isOwner) {
                Button(onClick = { vm.startGame() }, enabled = room.memberCount >= 2, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(if (game?.status == "finished") R.string.rematch else R.string.start_game))
                }
                if (room.memberCount < 2) Text(stringResource(R.string.need_two), color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else Text(stringResource(R.string.waiting_host), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SettingsPanel(room: Room, isOwner: Boolean, vm: RoomViewModel) {
    val s = room.settings
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            SwitchRow(stringResource(R.string.extra_turn_six), s.extraTurnOnSix, isOwner) { vm.updateSettings(s.copy(extraTurnOnSix = it)) }
            SwitchRow(stringResource(R.string.extra_turn_capture), s.extraTurnOnCapture, isOwner) { vm.updateSettings(s.copy(extraTurnOnCapture = it)) }
            SwitchRow(stringResource(R.string.safe_squares), s.safeSquares, isOwner) { vm.updateSettings(s.copy(safeSquares = it)) }
        }
    }
}

@Composable
private fun PlayingPanel(game: Game, myId: Long, vm: RoomViewModel) {
    val cur = game.current
    val myTurn = cur?.userId == myId
    // Player legend with turn marker
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        game.players.forEach { p ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(14.dp).clip(CircleShape).background(LudoBoard.seatColors[p.seat]))
                Spacer(Modifier.width(4.dp))
                Text((if (p.userId == cur?.userId) "▶ " else "") + p.name + (if (p.userId == myId) " (${stringResource(R.string.you)})" else ""),
                    style = MaterialTheme.typography.labelMedium)
            }
        }
    }
    Text(
        if (myTurn) stringResource(R.string.your_turn) else stringResource(R.string.waiting_for, cur?.name ?: ""),
        style = MaterialTheme.typography.titleMedium, color = if (myTurn) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
    )
    eventText(game)?.let { Text(it, style = MaterialTheme.typography.bodySmall) }

    LudoBoardView(game, myId, onTokenTap = vm::move)

    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Button(onClick = { vm.roll() }, enabled = myTurn && game.dice == null) { Text(stringResource(R.string.roll)) }
        game.dice?.let { Text(stringResource(R.string.dice_value, it), style = MaterialTheme.typography.titleLarge) }
    }
    if (myTurn && game.legal.isNotEmpty()) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            game.legal.forEach { i -> OutlinedButton(onClick = { vm.move(i) }) { Text(stringResource(R.string.move_token, i + 1)) } }
        }
    }
}

@Composable
private fun eventText(game: Game): String? {
    val e = game.event ?: return null
    val who = game.players.firstOrNull { it.userId == e.userId }?.name ?: return null
    return when (e.type) {
        "roll" -> stringResource(R.string.ev_rolled, who, e.dice ?: 0)
        "no_move" -> stringResource(R.string.ev_no_move, who, e.dice ?: 0)
        "three_sixes" -> stringResource(R.string.ev_three_sixes, who)
        "left" -> stringResource(R.string.ev_left, who)
        "move" -> if ((e.captured ?: 0) > 0) stringResource(R.string.ev_captured, who, e.captured ?: 0) else stringResource(R.string.ev_rolled, who, e.dice ?: 0)
        else -> null
    }
}

// ------------------------------------------------------------------ chat
@Composable
private fun ChatTab(vm: RoomViewModel) {
    val messages by vm.messages.collectAsStateWithLifecycle()
    val loading by vm.chatLoading.collectAsStateWithLifecycle()
    val hasMore by vm.hasMore.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().imePadding()) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (loading && messages.isEmpty()) LoadingBox()
            else MessageList(messages, vm.myId, showSender = true, modifier = Modifier.fillMaxSize(), canLoadOlder = hasMore, onLoadOlder = vm::loadOlder)
        }
        MessageInput(onSend = vm::sendChat)
    }
}

// ------------------------------------------------------------------ voice
@Composable
private fun VoiceTab(room: Room, vm: RoomViewModel) {
    val ctx = LocalContext.current
    val status by vm.voiceStatus.collectAsStateWithLifecycle()
    val muted by vm.voiceMuted.collectAsStateWithLifecycle()
    val speaking by vm.speaking.collectAsStateWithLifecycle()
    var micDenied by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        micDenied = !granted
        if (granted) vm.joinVoice()
    }
    val inVoice = status == VoiceStatus.Connecting || status == VoiceStatus.Connected

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            stringResource(when (status) {
                VoiceStatus.Idle -> R.string.voice_idle
                VoiceStatus.Connecting -> R.string.voice_connecting
                VoiceStatus.Connected -> R.string.voice_connected
                VoiceStatus.Error -> R.string.voice_failed
            }),
            style = MaterialTheme.typography.titleMedium,
        )
        if (micDenied) Text(stringResource(R.string.mic_permission), color = MaterialTheme.colorScheme.error)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (!inVoice) {
                Button(onClick = {
                    if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) vm.joinVoice()
                    else launcher.launch(Manifest.permission.RECORD_AUDIO)
                }) { Text(stringResource(R.string.join_voice)) }
            } else {
                Button(onClick = { vm.toggleMute() }) { Text(stringResource(if (muted) R.string.unmute else R.string.mute)) }
                OutlinedButton(onClick = { vm.leaveVoice() }) { Text(stringResource(R.string.leave_voice)) }
            }
        }

        val inVoiceMembers = room.members.filter { it.inVoice }
        if (inVoiceMembers.isEmpty()) EmptyBox(stringResource(R.string.no_voice_members))
        inVoiceMembers.forEach { m ->
            val talking = speaking.contains(m.id.toInt()) && !m.muted
            ListItem(
                leadingContent = { Avatar(m.displayName, online = m.online) },
                headlineContent = { Text(m.displayName + if (m.id == vm.myId) " (${stringResource(R.string.you)})" else "") },
                trailingContent = { Text(if (m.muted) "🔇" else if (talking) "🔊" else "🎙") },
            )
        }
    }
}
