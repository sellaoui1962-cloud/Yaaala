@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.seng.ludorooms.ui.auth

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.seng.ludorooms.AppGraph
import com.seng.ludorooms.R
import com.seng.ludorooms.data.ApiException
import com.seng.ludorooms.ui.common.InlineError
import com.seng.ludorooms.ui.common.graphViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

class AuthViewModel(private val g: AppGraph) : ViewModel() {
    data class Ui(val loading: Boolean = false, val error: String? = null)
    val ui = MutableStateFlow(Ui())
    val serverUrl: String get() = g.session.serverUrl

    fun submit(register: Boolean, username: String, password: String, displayName: String, server: String) {
        val u = username.trim()
        if (!Regex("^[A-Za-z0-9_]{3,20}$").matches(u)) { ui.value = Ui(error = "invalid_username"); return }
        if (register && password.length < 8) { ui.value = Ui(error = "invalid_password"); return }
        viewModelScope.launch {
            ui.value = Ui(loading = true)
            try {
                if (server.isNotBlank()) g.session.serverUrl = server
                val r = if (register) g.api.register(u, password, displayName.trim().ifEmpty { u }) else g.api.login(u, password)
                g.session.save(r) // flips loggedIn -> navigation moves to Home
                ui.value = Ui()
            } catch (e: ApiException) {
                ui.value = Ui(error = e.code)
            }
        }
    }
}

@Composable
fun AuthScreen() {
    val vm = graphViewModel { AuthViewModel(it) }
    val ui by vm.ui.collectAsStateWithLifecycle()
    var register by rememberSaveable { mutableStateOf(false) }
    var username by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var displayName by rememberSaveable { mutableStateOf("") }
    var server by rememberSaveable { mutableStateOf(vm.serverUrl) }
    var showServer by rememberSaveable { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp).imePadding(),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(stringResource(R.string.app_name), style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !register, onClick = { register = false }, label = { Text(stringResource(R.string.sign_in)) })
            FilterChip(selected = register, onClick = { register = true }, label = { Text(stringResource(R.string.register)) })
        }
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(username, { username = it }, Modifier.fillMaxWidth(), singleLine = true,
            label = { Text(stringResource(R.string.username)) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii))
        if (register) {
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(displayName, { displayName = it.take(30) }, Modifier.fillMaxWidth(), singleLine = true,
                label = { Text(stringResource(R.string.display_name)) })
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(password, { password = it }, Modifier.fillMaxWidth(), singleLine = true,
            label = { Text(stringResource(R.string.password)) }, visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
        TextButton(onClick = { showServer = !showServer }) { Text(stringResource(R.string.advanced)) }
        if (showServer) {
            OutlinedTextField(server, { server = it }, Modifier.fillMaxWidth(), singleLine = true,
                label = { Text(stringResource(R.string.server_url)) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri))
        }
        InlineError(ui.error)
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = { vm.submit(register, username, password, displayName, server) },
            enabled = !ui.loading && username.isNotBlank() && password.isNotEmpty(),
            modifier = Modifier.fillMaxWidth(),
        ) {
            if (ui.loading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
            else Text(stringResource(if (register) R.string.register else R.string.sign_in))
        }
    }
}
