package com.seng.ludorooms

import android.net.Uri
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.seng.ludorooms.ui.HomeScreen
import com.seng.ludorooms.ui.LudoTheme
import com.seng.ludorooms.ui.auth.AuthScreen
import com.seng.ludorooms.ui.dm.DmScreen
import com.seng.ludorooms.ui.room.RoomScreen

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val graph = (application as App).graph
        setContent { LudoTheme { AppRoot(graph) } }
    }
}

@Composable
fun AppRoot(graph: AppGraph) {
    val loggedIn by graph.session.loggedIn.collectAsStateWithLifecycle()
    val nav = rememberNavController()

    LaunchedEffect(loggedIn) {
        val target = if (loggedIn) "home" else "auth"
        if (nav.currentDestination?.route != target) nav.navigate(target) { popUpTo(0) { inclusive = true } }
    }

    NavHost(nav, startDestination = if (loggedIn) "home" else "auth") {
        composable("auth") { AuthScreen() }
        composable("home") {
            HomeScreen(
                onOpenRoom = { id -> nav.navigate("room/$id") },
                onOpenDm = { id, name -> nav.navigate("dm/$id?name=${Uri.encode(name)}") },
            )
        }
        composable("room/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
            RoomScreen(roomId = e.arguments!!.getLong("id"), onBack = { nav.popBackStack() })
        }
        composable(
            "dm/{id}?name={name}",
            arguments = listOf(
                navArgument("id") { type = NavType.LongType },
                navArgument("name") { type = NavType.StringType; defaultValue = "" },
            ),
        ) { e ->
            DmScreen(userId = e.arguments!!.getLong("id"), name = e.arguments?.getString("name").orEmpty(), onBack = { nav.popBackStack() })
        }
    }
}
