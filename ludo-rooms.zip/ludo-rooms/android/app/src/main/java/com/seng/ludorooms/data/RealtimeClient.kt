package com.seng.ludorooms.data

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.boolean
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.long
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.util.concurrent.TimeUnit

sealed interface RtEvent {
    data class RoomState(val room: Room) : RtEvent
    data class GameState(val roomId: Long, val game: Game) : RtEvent
    data class Chat(val message: ChatMessage) : RtEvent
    data class Dm(val message: ChatMessage) : RtEvent
    data class Presence(val userId: Long, val online: Boolean) : RtEvent
    data class RoomLeft(val roomId: Long) : RtEvent
    data object FriendsChanged : RtEvent
    data class Error(val code: String, val ref: String?) : RtEvent
}

/** One WebSocket with automatic reconnect (exponential backoff). The server resends room/game state on every connect. */
class RealtimeClient(
    private val session: SessionStore,
    private val api: ApiClient,
    private val scope: CoroutineScope,
) {
    private val http = OkHttpClient.Builder().pingInterval(25, TimeUnit.SECONDS).build()
    val events = MutableSharedFlow<RtEvent>(extraBufferCapacity = 128)
    val connected = MutableStateFlow(false)

    @Volatile private var ws: WebSocket? = null
    @Volatile private var wanted = false
    private var job: Job? = null
    private var backoff = 1000L

    fun start() {
        if (wanted) return
        wanted = true
        job = scope.launch { loop() }
    }

    fun stop() {
        wanted = false
        job?.cancel(); job = null
        ws?.close(1000, null); ws = null
        connected.value = false
    }

    fun send(obj: JsonObject): Boolean = ws?.send(obj.toString()) == true

    private suspend fun loop() {
        while (wanted) {
            val token = api.validAccessToken()
            if (token == null) { delay(backoff); bump(); continue }
            val done = CompletableDeferred<Unit>()
            val url = session.serverUrl.replaceFirst("http", "ws") + "/ws?token=" + token
            val socket = try {
                http.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
                    override fun onOpen(webSocket: WebSocket, response: Response) { connected.value = true; backoff = 1000L }
                    override fun onMessage(webSocket: WebSocket, text: String) { handle(text) }
                    override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { done.complete(Unit) }
                    override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) { done.complete(Unit) }
                })
            } catch (e: IllegalArgumentException) { delay(backoff); bump(); continue }
            ws = socket
            try { done.await() } finally { socket.cancel() }
            connected.value = false
            if (!wanted) break
            delay(backoff); bump()
        }
    }

    private fun bump() { backoff = (backoff * 2).coerceAtMost(30_000L) }

    private fun handle(text: String) {
        try {
            val o = api.json.parseToJsonElement(text).jsonObject
            val ev: RtEvent? = when (o["t"]?.jsonPrimitive?.content) {
                "room.state" -> RtEvent.RoomState(api.json.decodeFromJsonElement(Room.serializer(), o["room"]!!))
                "game.state" -> RtEvent.GameState(o["roomId"]!!.jsonPrimitive.long, api.json.decodeFromJsonElement(Game.serializer(), o["game"]!!))
                "chat.message" -> RtEvent.Chat(api.json.decodeFromJsonElement(ChatMessage.serializer(), o["message"]!!))
                "dm.message" -> RtEvent.Dm(api.json.decodeFromJsonElement(ChatMessage.serializer(), o["message"]!!))
                "presence" -> RtEvent.Presence(o["userId"]!!.jsonPrimitive.long, o["online"]!!.jsonPrimitive.boolean)
                "room.left" -> RtEvent.RoomLeft(o["roomId"]!!.jsonPrimitive.long)
                "friend.request", "friend.accepted" -> RtEvent.FriendsChanged
                "error" -> RtEvent.Error(o["code"]?.jsonPrimitive?.content ?: "", o["ref"]?.jsonPrimitive?.content)
                else -> null
            }
            if (ev != null) events.tryEmit(ev)
        } catch (_: Exception) { /* ignore malformed frames */ }
    }
}
