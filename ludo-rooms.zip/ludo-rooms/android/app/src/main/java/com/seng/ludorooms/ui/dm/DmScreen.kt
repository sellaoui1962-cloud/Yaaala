@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.seng.ludorooms.ui.dm

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.seng.ludorooms.AppGraph
import com.seng.ludorooms.R
import com.seng.ludorooms.data.ApiException
import com.seng.ludorooms.data.ChatMessage
import com.seng.ludorooms.data.RtEvent
import com.seng.ludorooms.ui.common.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class DmViewModel(private val g: AppGraph, private val otherId: Long) : ViewModel() {
    val messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val loading = MutableStateFlow(true)
    val hasMore = MutableStateFlow(false)
    val error = MutableStateFlow<String?>(null)
    val myId: Long get() = g.session.userId

    private fun merge(add: List<ChatMessage>) = messages.update { cur -> (cur + add).distinctBy { it.id }.sortedBy { it.id } }

    init {
        load()
        viewModelScope.launch {
            g.realtime.events.collect { ev ->
                if (ev is RtEvent.Dm && (ev.message.senderId == otherId || ev.message.recipientId == otherId)) merge(listOf(ev.message))
            }
        }
    }

    fun load() {
        viewModelScope.launch {
            loading.value = true; error.value = null
            try {
                val h = g.api.dmHistory(otherId)
                merge(h); hasMore.value = h.size >= 50
            } catch (e: ApiException) { error.value = e.code }
            loading.value = false
        }
    }

    fun loadOlder() {
        val first = messages.value.firstOrNull() ?: return
        viewModelScope.launch {
            try { val h = g.api.dmHistory(otherId, first.id); merge(h); hasMore.value = h.size >= 50 }
            catch (e: ApiException) { error.value = e.code }
        }
    }

    fun send(text: String) {
        viewModelScope.launch {
            try { merge(listOf(g.api.sendDm(otherId, text))) } catch (e: ApiException) { error.value = e.code }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DmScreen(userId: Long, name: String, onBack: () -> Unit) {
    val vm = graphViewModel(key = "dm$userId") { DmViewModel(it, userId) }
    val messages by vm.messages.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    val error by vm.error.collectAsStateWithLifecycle()
    val hasMore by vm.hasMore.collectAsStateWithLifecycle()

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(name) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) } },
        )
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().imePadding()) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when {
                    loading && messages.isEmpty() -> LoadingBox()
                    error != null && messages.isEmpty() -> ErrorBox(error!!, onRetry = vm::load)
                    else -> MessageList(messages, vm.myId, showSender = false, modifier = Modifier.fillMaxSize(),
                        canLoadOlder = hasMore, onLoadOlder = vm::loadOlder)
                }
            }
            InlineError(error.takeIf { messages.isNotEmpty() }, Modifier.padding(horizontal = 16.dp))
            MessageInput(onSend = vm::send)
        }
    }
}
