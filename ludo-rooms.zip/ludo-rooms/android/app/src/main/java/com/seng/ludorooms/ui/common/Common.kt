package com.seng.ludorooms.ui.common

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.seng.ludorooms.App
import com.seng.ludorooms.AppGraph
import com.seng.ludorooms.R

@Composable
fun errorMessage(code: String): String = stringResource(
    when (code) {
        "network" -> R.string.err_network
        "invalid_credentials" -> R.string.err_invalid_credentials
        "username_taken" -> R.string.err_username_taken
        "invalid_username" -> R.string.err_invalid_username
        "invalid_password" -> R.string.err_invalid_password
        "too_many_attempts" -> R.string.err_too_many
        "room_full" -> R.string.err_room_full
        "game_in_progress" -> R.string.err_game_in_progress
        "forbidden", "not_friends", "owner_only", "not_member" -> R.string.err_forbidden
        "not_your_turn" -> R.string.err_not_your_turn
        "voice_not_configured" -> R.string.err_voice_not_configured
        "rate_limited" -> R.string.err_rate_limited
        else -> R.string.err_generic
    }
)

@Composable
inline fun <reified VM : ViewModel> graphViewModel(key: String? = null, crossinline create: (AppGraph) -> VM): VM {
    val graph = (LocalContext.current.applicationContext as App).graph
    return viewModel(key = key, factory = viewModelFactory { initializer { create(graph) } })
}

@Composable
fun LoadingBox(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
}

@Composable
fun ErrorBox(code: String, onRetry: () -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(errorMessage(code), textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.error)
        Spacer(Modifier.height(12.dp))
        Button(onClick = onRetry) { Text(stringResource(R.string.retry)) }
    }
}

@Composable
fun EmptyBox(text: String, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(text, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun InlineError(code: String?, modifier: Modifier = Modifier) {
    if (code != null) Text(errorMessage(code), color = MaterialTheme.colorScheme.error, modifier = modifier.padding(vertical = 4.dp))
}

@Composable
fun Avatar(name: String, online: Boolean? = null, modifier: Modifier = Modifier) {
    Box(modifier.size(40.dp)) {
        Box(
            Modifier.fillMaxSize().clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center,
        ) { Text(name.take(1).uppercase(), color = MaterialTheme.colorScheme.onPrimaryContainer) }
        if (online != null) {
            Box(
                Modifier.size(12.dp).align(Alignment.BottomEnd).clip(CircleShape)
                    .background(if (online) Color(0xFF2E7D32) else Color(0xFF9E9E9E))
            )
        }
    }
}
