#!/bin/bash
# Builds the debug APK. Needs JDK 17, Android SDK 34 (ANDROID_HOME set) and internet access.
set -e
cd "$(dirname "$0")"
[ -f gradlew ] || gradle wrapper --gradle-version 8.7
./gradlew assembleDebug ${SERVER_URL:+-PserverUrl=$SERVER_URL}
echo "APK: $(pwd)/app/build/outputs/apk/debug/app-debug.apk"
