# Ludo Rooms — Android app + independent backend

A voice-room Ludo app: accounts, friends with presence, room discovery, server-authoritative multiplayer Ludo,
room/private chat and voice chat. Arabic + English UI (RTL supported).

> **This is an independent product. It is NOT connected to Yalla's servers** and does not use, extract or bypass
> anything from the Yalla Ludo APK (which was only inspected and left untouched). Everything here talks to the
> backend in `backend/`, which you operate yourself. If you later obtain *official* Yalla API access, it would be
> an additional integration layer; none exists in this code.

```
ludo-rooms/
├── android/    Android Studio project (Kotlin, Jetpack Compose, Navigation, OkHttp, kotlinx.serialization, Agora voice SDK)
├── backend/    Node.js >= 22.5 server, ZERO npm dependencies (built-in http, node:sqlite, hand-written WebSocket)
│   ├── migrations/001_init.sql   SQLite schema (applied automatically at start, tracked in schema_migrations)
│   ├── src/                      app.js (REST) · hub.js (rooms/game/chat/voice/presence) · engine/ludo.js (rules) · ws.js · auth.js · agora.js
│   └── test/                     26 automated tests (engine, REST API, WebSocket realtime)
├── README.md   this file
├── STATUS.md   what is verified and what is not (read this first)
└── build_apk.sh
```

## Features (all implemented in source; see STATUS.md for what has actually been tested)
| Area | What exists |
|---|---|
| Login | register / login, 15-min access token + rotating 30-day refresh token, automatic refresh, logout, login throttling |
| Friends | list with online/offline (pushed over WebSocket), user search, requests (send/accept/decline/remove), see which room a friend is in, **Open room** when authorized, private messages with history |
| Rooms | discovery list with search, member list, join/leave, create (name, private=friends-only, 2–4 players, settings), owner transfer, idle-room cleanup |
| Ludo | full rules on the server: roll 6 to leave base, exact roll to finish, captures, safe squares, 3 sixes = lost turn, extra turn on 6 / capture (settings), 2–4 players, ranking, rematch, leave mid-game; clients only render state; state persisted in SQLite and replayed on reconnect |
| Voice | Agora RTC; tokens minted by YOUR backend with YOUR Agora project; join/leave, mute/unmute, participant list with speaking indicator, token renewal |
| Chat | room chat + private messages, paged history, rate limiting |
| Performance | one WebSocket (no polling), debounced searches, paged history, server-pushed state, auto-reconnect with backoff |
| i18n | `values/` (English) and `values-ar/` (Arabic), in-app language switch |

## 1. Run the backend
Requires Node.js **22.5 or newer** (uses the built-in `node:sqlite`). No `npm install` is needed.
```bash
cd backend
npm test                      # 26 tests
npm start                     # listens on :8080, DB in ./data/ludo.db
# optional voice:
AGORA_APP_ID=<your app id> AGORA_APP_CERTIFICATE=<your certificate> npm start
```
Environment: `PORT`, `DB_PATH`, `AGORA_APP_ID`, `AGORA_APP_CERTIFICATE` (see `.env.example`).
Voice needs your own free Agora project (console.agora.io). Without it the voice tab shows "not configured".

## 2. Build the Android app
Requirements: JDK 17, Android Studio (Koala+) or Android SDK 34 + Gradle 8.7, internet access for dependencies.
```bash
cd android
./build_apk.sh                # or: gradle wrapper --gradle-version 8.7 && ./gradlew assembleDebug
# point the app at your server (default http://10.0.2.2:8080 = host machine from the emulator):
./gradlew assembleDebug -PserverUrl=http://192.168.1.20:8080
adb install -r app/build/outputs/apk/debug/app-debug.apk
```
The server URL can also be changed at runtime from the login screen ("Server settings").
Or simply open the `android/` folder in Android Studio and press Run.


## Build the APK on GitHub Actions (no local Android SDK needed)
1. Create a GitHub repository and push the **contents of this folder** (so `.github/`, `android/`, `backend/` are at the repo root).
2. Open the **Actions** tab. The workflow *Build Ludo Rooms* runs on every push, or run it by hand (**Run workflow**) and optionally type your server URL.
3. When it finishes, open the run and download the artifact **ludo-rooms-debug-apk** (contains `app-debug.apk`, debug-signed, installable on any phone with "install unknown apps" enabled).
4. To bake in your server address permanently: *Settings -> Secrets and variables -> Actions -> Variables -> New variable* named `SERVER_URL` (e.g. `https://ludo.example.com`). The default `http://10.0.2.2:8080` only works from the emulator; the URL can always be changed in the app on the login screen.

The first run is the first real compile of the Kotlin code. If it fails, download the **build-reports** artifact (or copy the red log lines) and send them back to get fixed.

## 3. Try it
Create two accounts (two emulators/phones), add each other as friends, create a room on one, open it from the
other's friends list, start the game from the host, play, chat, and (with Agora configured) join voice.

## Security notes / production checklist
* Cleartext HTTP is enabled for development (`usesCleartextTraffic`). Put the backend behind HTTPS/WSS (reverse proxy) and disable it.
* Tokens are stored in private SharedPreferences; consider Keystore-backed encrypted storage.
* Passwords: scrypt with per-user salt. Login is throttled per IP+username; chat is rate limited.
* The Agora App Certificate lives only on the server.
* The WebSocket is hand-written to keep the backend dependency-free; for heavy production load prefer a mature library (`ws`) and a process manager.
